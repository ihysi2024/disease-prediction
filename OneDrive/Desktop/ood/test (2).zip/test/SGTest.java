import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import cs3500.samegame.model.hw02.FourPieceSameGame;
import cs3500.samegame.model.hw02.Piece;
import cs3500.samegame.model.hw02.PieceType;
import cs3500.samegame.view.SameGameTextView;

public class SGTest {

  FourPieceSameGame fpsgRandom;
  FourPieceSameGame fpsgDeterm;
  FourPieceSameGame fpsgRandomSmall;
  FourPieceSameGame fpsgDetermSmall;
  List<List<Piece>> allPieces;

  SameGameTextView sgvRandom;
  SameGameTextView sgvDeterm;

  SameGameTextView sgvRandomSmall;

  SameGameTextView sgvDetermSmall;
  List<List<Piece>> determRows;

  FourPieceSameGame fpsgOneVFour;
  List<Piece> row2;
  List<Piece> row1;

  @Before
  public void setUp() {
    this.allPieces  = new ArrayList<>();
    this.fpsgOneVFour = new FourPieceSameGame(this.allPieces, 1, 4, 2, 0);
    this.fpsgRandomSmall = new FourPieceSameGame(this.allPieces, 2,5 , 2, 0);
    this.fpsgDetermSmall = new FourPieceSameGame(this.allPieces, 2, 5, 2, 0);
    this.fpsgRandom = new FourPieceSameGame(this.allPieces, 8, 9, 2, 0);
    this.fpsgDeterm = new FourPieceSameGame(this.allPieces, 8, 9, 2, 0);
    this.sgvRandom = new SameGameTextView(this.fpsgRandom);
    this.sgvDeterm = new SameGameTextView(this.fpsgDeterm);
    this.sgvRandomSmall = new SameGameTextView(this.fpsgRandomSmall);
    this.sgvDetermSmall = new SameGameTextView(this.fpsgDetermSmall);
    this.determRows = new ArrayList();
    this.row1 = new ArrayList<>();
    this.row1.add(new Piece(PieceType.RED, 0,0));
    this.row1.add(new Piece(PieceType.RED, 0,1));
    this.row1.add(new Piece(PieceType.BLUE, 0,2));
    this.row1.add(new Piece(PieceType.RED, 0,3));
    this.row1.add(new Piece(PieceType.RED, 0,4));
    this.row2 = new ArrayList();
    this.row2.add(new Piece(PieceType.BLUE, 1,0));
    this.row2.add(new Piece(PieceType.RED, 1,1));
    this.row2.add(new Piece(PieceType.BLUE, 1,2));
    this.row2.add(new Piece(PieceType.YELLOW, 1,3));
    this.row2.add(new Piece(PieceType.RED, 1,4));
    this.determRows.add(this.row1);
    this.determRows.add(this.row2);
  }

  @Test
  // tests
  public void testRender() throws IOException {
    Appendable ap = new StringBuilder("");
    this.fpsgDetermSmall.startGame(2, 5, 2, false);
    SameGameTextView sgDetermSmall = new SameGameTextView(this.fpsgDetermSmall, ap);
    String manualRender = "R G B Y R\nG B Y R G";
    sgDetermSmall.render();
    Assert.assertEquals(manualRender, ap.toString());
  }



  @Test
  public void removeMatch() {
    List<List<Piece>> pieces = new ArrayList<>();
    FourPieceSameGame fpsg1 = new FourPieceSameGame(pieces, 6, 5, 0, 2);
    List<Piece> row1 = new ArrayList();
    row1.add(new Piece(PieceType.RED, 0, 0));
    row1.add(new Piece(PieceType.GREEN, 0, 1));
    row1.add(new Piece(PieceType.BLUE, 0, 2));
    row1.add(new Piece(PieceType.YELLOW, 0, 3));
    row1.add(new Piece(PieceType.RED, 0, 4));
    List<Piece> row2 = new ArrayList();
    row2.add(new Piece(PieceType.GREEN, 1, 0));
    row2.add(new Piece(PieceType.EMPTY, 1, 1));
    row2.add(new Piece(PieceType.YELLOW, 1, 2));
    row2.add(new Piece(PieceType.RED, 1, 3));
    row2.add(new Piece(PieceType.GREEN, 1, 4));
    List<Piece> row3 = new ArrayList();
    row3.add(new Piece(PieceType.YELLOW, 2, 0));
    row3.add(new Piece(PieceType.EMPTY, 2, 1));
    row3.add(new Piece(PieceType.RED, 2, 2));
    row3.add(new Piece(PieceType.BLUE, 2, 3));
    row3.add(new Piece(PieceType.BLUE, 2, 4));
    List<Piece> row4 = new ArrayList();
    row4.add(new Piece(PieceType.YELLOW, 3, 0));
    row4.add(new Piece(PieceType.EMPTY, 3, 1));
    row4.add(new Piece(PieceType.EMPTY, 3, 2));
    row4.add(new Piece(PieceType.RED, 3, 3));
    row4.add(new Piece(PieceType.YELLOW, 3, 4));
    List<Piece> row5 = new ArrayList();
    row5.add(new Piece(PieceType.RED, 4, 0));
    row5.add(new Piece(PieceType.EMPTY, 4, 1));
    row5.add(new Piece(PieceType.EMPTY, 4, 2));
    row5.add(new Piece(PieceType.YELLOW, 4, 3));
    row5.add(new Piece(PieceType.RED, 4, 4));
    pieces.add(row1);
    pieces.add(row2);
    pieces.add(row3);
    pieces.add(row4);
    pieces.add(row5);
    fpsg1.startGame(pieces, 0);
    SameGameTextView sg1 = new SameGameTextView(fpsg1);
    //System.out.println(sg1.toString());
   // fpsg1.removeMatch(3, 1);
    System.out.println(sg1.toString());
    Assert.assertFalse(fpsg1.gameOver());

    //Assert.assertFalse(fpsg1.gameOver());
  }
}
