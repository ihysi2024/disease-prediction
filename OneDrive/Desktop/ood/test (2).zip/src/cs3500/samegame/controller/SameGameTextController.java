package cs3500.samegame.controller;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import cs3500.samegame.model.hw02.SameGameModel;
import cs3500.samegame.view.SameGameTextView;

public class SameGameTextController<T> implements SameGameController<T> {
  private Readable readable;
  private Appendable appendable;
  public SameGameTextController(Readable rd, Appendable ap) {
    if ((rd == null) || (ap == null)) {
      throw new IllegalArgumentException("Input and Output are empty");
    }
    this.readable = rd;
    this.appendable = ap;

  }

  @Override
  public void playGame(SameGameModel<T> model, int rows, int cols, int swaps, boolean isRandom)
          throws IllegalStateException {

    int fromRow;
    int toRow;
    int fromCol;
    int toCol;
    boolean quit = false;
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    // start the game
    try {
      model.startGame(rows, cols, swaps, isRandom);
    }
    catch (Exception startE) {
      writeMessage("Error: " + startE.getMessage() + System.lineSeparator());
    }

    // generate a view of the game with the current appendable
    SameGameTextView view = new SameGameTextView(model, this.appendable);

    // collect the user input through a scanner
    Scanner sc = new Scanner(this.readable);

    // while the user has not quit and the game is not over
    while (!quit || model.gameOver()) {
      // try attaching the board view to the appendable
      try {
        view.render();
      } catch (IOException e) {
        throw new RuntimeException();
      }
      // let the user know the remaining score & swaps
      writeMessage("Remaining Swaps: " + model.remainingSwaps() + System.lineSeparator());
      writeMessage("Score: " + model.score() + System.lineSeparator());

      // collect the kind of move the user wants to make
      String userMove = sc.next();
      switch (userMove) {
        case "quit":
        case "q":
          quit = true;
          break;
        case "m":  // if the user wants to try removing a match
          try {
            // collect the indices of the piece to try removing
            fromRow = sc.nextInt() - 1;
            fromCol = sc.nextInt() - 1;
            // try and remove
            model.removeMatch(fromRow, fromCol);
          } catch (Exception matchE) {
            writeMessage("Error: " + matchE.getMessage() + System.lineSeparator());
          }
          break;
        case "s": // if the user wants to swap
          try {
            // collect the indices of the two pieces to swap
            fromRow = sc.nextInt() - 1;
            fromCol = sc.nextInt() - 1;
            toRow = sc.nextInt() - 1;
            toCol = sc.nextInt() - 1;
            model.swap(fromRow, fromCol, toRow, toCol);
          } catch (Exception swapE) {
            writeMessage("Error: " + swapE.getMessage() + System.lineSeparator());
          }
          break;
        default:
          writeMessage("Invalid move. Try Again. ");
      }

    }
    if (model.gameOver()) {
      writeMessage("Game Over" + System.lineSeparator());
      try {
        view.render();
      } catch (Exception e) {
        throw new RuntimeException();
      }
      writeMessage("Remaining Swaps: " + model.remainingSwaps() + System.lineSeparator());
      writeMessage("Score: " + model.score() + System.lineSeparator());
    }

    if (quit) {
      writeMessage("Game quit!" + System.lineSeparator());
      writeMessage("State of game when quit:" + System.lineSeparator());
      try {
        view.render();
      } catch (Exception e) {
        throw new RuntimeException();
      }
      writeMessage("Remaining Swaps: " + model.remainingSwaps() + System.lineSeparator());
    }

  }

  @Override
  public void playGame(SameGameModel<T> model, List<List<T>> board, int swaps) throws IllegalStateException {
    int fromRow;
    int toRow;
    int fromCol;
    int toCol;
    boolean quit = false;
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    // start the game
    Scanner sc = new Scanner(this.readable);
    try {
      model.startGame(board, swaps);
    }
    catch (Exception e) {
      throw new IllegalStateException("Game cannot be started");
    }
    // generate a view of the game with the current appendable
    SameGameTextView view = new SameGameTextView(model, this.appendable);

    // while the user has not quit and the game is not over
    while (!quit || model.gameOver()) {
      // try attaching the board view to the appendable
      try {
        view.render();
      } catch (IOException e) {
        throw new RuntimeException();
      }
      // let the user know the remaining score & swaps
      writeMessage("Remaining Swaps: " + model.remainingSwaps() + System.lineSeparator());
      writeMessage("Score: " + model.score() + System.lineSeparator());

      // collect the kind of move the user wants to make
      String userMove = sc.next();
      switch (userMove) {
        case "quit":
        case "q":
          quit = true;
          break;
        case "m":  // if the user wants to try removing a match
          try {
            // collect the indices of the piece to try removing
            fromRow = sc.nextInt() - 1;
            fromCol = sc.nextInt() - 1;
            // try and remove
            model.removeMatch(fromRow, fromCol);
          } catch (Exception matchE) {
            writeMessage("Error: " + matchE.getMessage() + System.lineSeparator());
          }
          break;
        case "s": // if the user wants to swap
          try {
            // collect the indices of the two pieces to swap
            fromRow = sc.nextInt() - 1;
            fromCol = sc.nextInt() - 1;
            toRow = sc.nextInt() - 1;
            toCol = sc.nextInt() - 1;
            model.swap(fromRow, fromCol, toRow, toCol);
          } catch (Exception swapE) {
            writeMessage("Error: " + swapE.getMessage() + System.lineSeparator());
          }
          break;
        default:
          writeMessage("Invalid move. Try Again. ");
      }

    }
    if (model.gameOver()) {
      writeMessage("Game Over" + System.lineSeparator());
      try {
        view.render();
      } catch (Exception e) {
        throw new RuntimeException();
      }
      writeMessage("Remaining Swaps: " + model.remainingSwaps() + System.lineSeparator());
      writeMessage("Score: " + model.score() + System.lineSeparator());
    }

    if (quit) {
      writeMessage("Game quit!" + System.lineSeparator());
      writeMessage("State of game when quit:" + System.lineSeparator());
      try {
        view.render();
      } catch (Exception e) {
        throw new RuntimeException();
      }
      writeMessage("Remaining Swaps: " + model.remainingSwaps() + System.lineSeparator());
    }

  }

  protected void writeMessage(String message) throws IllegalStateException {
    try {
      appendable.append(message);

    } catch (IOException e) {
      throw new IllegalStateException(e.getMessage());
    }
  }
}