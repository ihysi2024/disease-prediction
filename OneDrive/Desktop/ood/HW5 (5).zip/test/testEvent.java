import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import model.Event;
import model.Schedule;
import model.Time;
import model.User;

public class testEvent {


  private Event morningLec;
  private Event morningLecOverlapping;
  private Event morningLecSameTime;
  private Event morningLecEndTime;
  private Event afternoonLec;

  private Event sleep;

  private Schedule emptySchedule;

  private User profLuciaUser;

  private User studentAnonUser;

  private User chatUser;



  @Before
  public void setUp() {
    this.emptySchedule = new Schedule(new ArrayList<>());

    this.profLuciaUser = new User("Prof Lucia", emptySchedule);
    this.studentAnonUser = new User("Student Anon", emptySchedule);
    this.chatUser = new User("Chat", emptySchedule);

    this.morningLec = new Event("CS3500 Morning Lecture",
            new Time( Time.Day.TUESDAY, 9, 50),
            new Time(Time.Day.TUESDAY, 11, 30),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));

    // same time as the morning lecture
    this.morningLecSameTime = new Event("same time morning lecture",
            new Time( Time.Day.TUESDAY, 9, 50),
            new Time(Time.Day.TUESDAY, 11, 30),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));

    // overlapping time as the morning lecture
    this.morningLecOverlapping = new Event("overlapping morning lecture ",
            new Time( Time.Day.TUESDAY, 8, 30),
            new Time(Time.Day.TUESDAY, 10, 30),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));

    // start time same as end time of morning lecture
    this.morningLecEndTime = new Event("same start time as end time",
            new Time( Time.Day.TUESDAY, 11, 30),
            new Time(Time.Day.TUESDAY, 12, 15),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));


    this.afternoonLec = new Event("CS3500 Afternoon Lecture",
            new Time(Time.Day.TUESDAY, 13, 35),
            new Time(Time.Day.TUESDAY, 15, 15),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Chat")));

    this.sleep = new Event("Sleep",
            new Time(Time.Day.FRIDAY, 18, 0),
            new Time(Time.Day.SUNDAY, 12, 0),
            true,
            "Home",
            new ArrayList<>(Arrays.asList("Prof. Lucia")));



  }

  @Test
  public void testStartEndTime() {
    // exactly a week-long event or event has no duration
    Assert.assertThrows(IllegalArgumentException.class, () -> new Event("Meeting",
            new Time(Time.Day.TUESDAY, 13, 00),
            new Time(Time.Day.TUESDAY, 13, 00),
            true, "LA",
            List.of("Prof. Lucia")));


    // end time is null
    Assert.assertThrows(IllegalArgumentException.class, () -> new Event("Meeting",
            new Time(Time.Day.TUESDAY, 13, 00),
            null,
            true, "LA",
            List.of("Prof. Lucia")));

    // start time is null
    Assert.assertThrows(IllegalArgumentException.class, () -> new Event("Meeting",
            null,
            new Time(Time.Day.TUESDAY, 13, 00),
            true, "LA",
            List.of("Prof. Lucia")));

    // there are no invitees/hosts
    Assert.assertThrows(IllegalArgumentException.class, () -> new Event("Meeting",
            new Time(Time.Day.TUESDAY, 13, 00),
            new Time(Time.Day.TUESDAY, 11, 00),
            true, "LA",
            List.of()));

    // the event has no name
    Assert.assertThrows(IllegalArgumentException.class, () -> new Event(null,
            new Time( Time.Day.TUESDAY, 18, 00),
            new Time(Time.Day.TUESDAY, 16, 00),
            true, "LA",
            List.of("Prof. Lucia")));

  }


  @Test
  public void testAddEvent() {
    // starting schedule - no events yet
    Assert.assertEquals(0, emptySchedule.getEvents().size());
    // add a valid event
    emptySchedule.addEvent(this.morningLec);
    Assert.assertEquals(1, emptySchedule.getEvents().size());

    // adding class at the same time or overlapping time
    Assert.assertThrows(IllegalArgumentException.class,
            () -> emptySchedule.addEvent(this.morningLecSameTime));
    Assert.assertThrows(IllegalArgumentException.class,
            () -> emptySchedule.addEvent(this.morningLecOverlapping));

    // adding class that starts when previous class ends
    emptySchedule.addEvent(this.morningLecEndTime);
    Assert.assertEquals(2, emptySchedule.getEvents().size());
    emptySchedule.addEvent(this.afternoonLec);
    Assert.assertEquals(3, emptySchedule.getEvents().size());
  }



}
