import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import model.Event;
import model.NUPlanner;
import model.Schedule;
import model.Time;
import model.User;

public class testSchedule {
  private Event morningLec;
  private Event morningLecOverlapping;
  private Event morningLecSameTime;
  private Event morningLecEndTime;
  private Event morningSnack;

  private Event afternoonLec;
  private Event officeHours;

  private Event sleep;

  private Schedule luciaSchedule;

  private Schedule studentAnonSchedule;

  private Schedule chatSchedule;

  private Schedule emptySchedule;

  private User profLuciaUser;

  private User studentAnonUser;

  private User chatUser;
  private NUPlanner plannerSystem;
  private HashMap<String, String[]> morningLecMap;


  @Before
  public void setUp() {

    this.emptySchedule = new Schedule(new ArrayList<>());

    this.profLuciaUser = new User("Prof Lucia", emptySchedule);
    this.studentAnonUser = new User("Student Anon", emptySchedule);
    this.chatUser = new User("Chat", emptySchedule);

    this.morningLec = new Event("CS3500 Morning Lecture",
            new Time( Time.Day.TUESDAY, 9, 50),
            new Time(Time.Day.TUESDAY, 00, 01),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));

    // same time as the morning lecture
    this.morningLecSameTime = new Event("same time morning lecture",
            new Time( Time.Day.TUESDAY, 9, 50),
            new Time(Time.Day.TUESDAY, 11, 30),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList(
                    "Student Anon")));

    // overlapping time as the morning lecture
    this.morningLecOverlapping = new Event("overlapping morning lecture ",
            new Time( Time.Day.TUESDAY, 8, 30),
            new Time(Time.Day.TUESDAY, 10, 30),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));

    // start time same as end time of morning lecture
    this.morningLecEndTime = new Event("same start time as end time",
            new Time( Time.Day.TUESDAY, 11, 30),
            new Time(Time.Day.TUESDAY, 12, 15),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));

    // same time as the morning lecture
    this.morningLecSameTime = new Event("same time morning lecture",
            new Time( Time.Day.TUESDAY, 9, 50),
            new Time(Time.Day.TUESDAY, 11, 30),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));

    // overlapping time as the morning lecture
    this.morningLecOverlapping = new Event("overlapping morning lecture ",
            new Time( Time.Day.TUESDAY, 8, 30),
            new Time(Time.Day.TUESDAY, 10, 30),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));

    // start time same as end time of morning lecture
    this.morningLecEndTime = new Event("same start time as end time",
            new Time( Time.Day.TUESDAY, 11, 30),
            new Time(Time.Day.TUESDAY, 12, 15),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));

    this.afternoonLec = new Event("CS3500 Afternoon Lecture",
            new Time(Time.Day.TUESDAY, 13, 35),
            new Time(Time.Day.TUESDAY, 15, 15),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Chat")));

    this.sleep = new Event("Sleep",
            new Time(Time.Day.FRIDAY, 18, 0),
            new Time(Time.Day.SUNDAY, 12, 0),
            true,
            "Home",
            new ArrayList<>(Arrays.asList("Prof. Lucia")));

    this.luciaSchedule = new Schedule(new ArrayList<>(Arrays.asList(morningLec, afternoonLec, sleep)));
    this.studentAnonSchedule = new Schedule(new ArrayList<>(Arrays.asList(morningLec)));
    this.chatSchedule = new Schedule(new ArrayList<>(Arrays.asList(morningLec, afternoonLec)));

    this.profLuciaUser = new User("Prof. Lucia", luciaSchedule);
    this.studentAnonUser = new User("Student Anon", studentAnonSchedule);
    this.chatUser = new User("Chat", chatSchedule);

    this.morningSnack = new Event("snack",
            new Time(Time.Day.TUESDAY, 11, 30),
            new Time(Time.Day.TUESDAY, 11, 45),
            false,
            "Churchill Hall 101",
            List.of("Student Anon"));

    this.officeHours = new Event("office hours",
            new Time(Time.Day.MONDAY, 12, 01),
            new Time(Time.Day.MONDAY, 12, 30),
            false,
            "Churchill Hall 101",
            List.of("Student Anon",
                    "Prof. Lucia"));

    HashSet<User> users = new HashSet<User>();
    users.add(this.profLuciaUser);
    users.add(this.studentAnonUser);
    users.add(this.chatUser);
    this.plannerSystem = new NUPlanner(users);
  }

  @Test
  public void testExportXML() {

    profLuciaUser.userSchedToXML("src");
  }

  @Test
  public void testScheduleView() {
    Assert.assertEquals("", this.profLuciaUser.userToString());
  }


  @Test
  public void testAddEventToSchedule() {
    Assert.assertEquals(1, this.studentAnonSchedule.getEvents().size());
    this.plannerSystem.addEventForRelevantUsers(this.morningSnack);
    Assert.assertEquals(2, this.studentAnonSchedule.getEvents().size());
    Assert.assertEquals(2, this.chatSchedule.getEvents().size());
    Assert.assertEquals(3, this.luciaSchedule.getEvents().size());
    this.plannerSystem.addEventForRelevantUsers(this.officeHours);
    Assert.assertEquals(3, this.studentAnonSchedule.getEvents().size());
    Assert.assertEquals(4, this.luciaSchedule.getEvents().size());
    Assert.assertEquals(2, this.chatSchedule.getEvents().size());

    this.plannerSystem.addEventForRelevantUsers(this.officeHours);

  }

  @Test
  public void testRemove() {
    Assert.assertEquals(1, this.studentAnonSchedule.getEvents().size());
    this.studentAnonSchedule.removeEvent(this.morningLec);
    Assert.assertEquals(0, this.studentAnonSchedule.getEvents().size());
    Assert.assertEquals(2, this.chatSchedule.getEvents().size());
    Assert.assertEquals(3, this.luciaSchedule.getEvents().size());
    this.luciaSchedule.removeEvent(this.morningLec);
    this.studentAnonSchedule.removeEvent(this.officeHours);
    Assert.assertEquals(3, this.studentAnonSchedule.getEvents().size());
    Assert.assertEquals(4, this.luciaSchedule.getEvents().size());
    Assert.assertEquals(2, this.chatSchedule.getEvents().size());
  }
}
