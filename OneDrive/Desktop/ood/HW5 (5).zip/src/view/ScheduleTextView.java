package view;

public class ScheduleTextView implements ScheduleView {


}
