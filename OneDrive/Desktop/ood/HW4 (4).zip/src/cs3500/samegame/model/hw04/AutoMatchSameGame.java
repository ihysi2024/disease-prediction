package cs3500.samegame.model.hw04;

import java.util.List;

import cs3500.samegame.model.hw02.FourPieceSameGame;
import cs3500.samegame.model.hw02.Piece;
import cs3500.samegame.model.hw02.SameGameModel;

public class AutoMatchSameGame extends FourPieceSameGame {
    protected List<List<Piece>> board;
    protected int rows;
    protected int cols;
    protected int swaps;
    protected int score;
    FourPieceSameGame starterGame;

    public AutoMatchSameGame() {

    }
    public AutoMatchSameGame(FourPieceSameGame starterGame, int rows, int cols, int swaps, int score) {
      this.starterGame = new FourPieceSameGame(board, rows, cols, swaps, score);
    }

    @Override
    public void swap(int fromRow, int fromCol, int toRow, int toCol) {
      this.starterGame.swap(fromRow, fromCol, toRow, toCol);
    }

    @Override
    public void removeMatch(int row, int col) {
      this.starterGame.removeMatch(row, col);

    }

    @Override
    public int width() {
      return this.rows;
    }

    @Override
    public int length() {
      return this.starterGame.length();
    }

    @Override
    public Piece pieceAt(int row, int col) {
      return this.starterGame.pieceAt(row, col);
    }

    @Override
    public int score() {
      return this.starterGame.score();
    }

    @Override
    public int remainingSwaps() {
      return this.starterGame.remainingSwaps();
    }

    @Override
    public boolean gameOver() {
      return this.starterGame.gameOver();
    }

    @Override
    public void startGame(int rows, int cols, int swaps, boolean random) {
      this.starterGame.startGame(rows, cols, swaps, random);
    }

    @Override
    public Piece[] createListOfPieces() {
      return this.starterGame.createListOfPieces();
    }

    @Override
    public void startGame(List<List<Piece>> board, int swaps) {
      this.starterGame.startGame(board, swaps);
    }
  }