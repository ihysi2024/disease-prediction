package cs3500.samegame.controller;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import cs3500.samegame.model.hw02.SameGameModel;
import cs3500.samegame.view.SameGameTextView;

public class SameGameTextController<T> implements SameGameController<T> {
  private Readable readable;
  private Appendable appendable;

  private boolean quit;

  public SameGameTextController(Readable rd, Appendable ap) throws IllegalStateException {
    if ((rd == null) || (ap == null)) {
      throw new IllegalArgumentException("Input and Output are empty");
    }
    this.readable = rd;
    this.appendable = ap;

  }

  @Override
  public void playGame(SameGameModel<T> model, int rows, int cols, int swaps, boolean isRandom)
          throws IllegalStateException {
    this.quit = false;
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }

    Scanner sc = new Scanner(this.readable);
    // start the game
    try {
      model.startGame(rows, cols, swaps, isRandom);
    } catch (Exception startE) {
      writeMessage("Error: " + startE.getMessage() + System.lineSeparator());
    }

    SameGameTextView view = new SameGameTextView(model, this.appendable);

    respondToUserMove(model, sc, view);

    visualizeGameOver(model, view);

    visualizeQuit(model, view);

  }

  private void visualizeQuit(SameGameModel<T> model, SameGameTextView view) {
    if (this.quit) {
      writeMessage("Game quit!" + System.lineSeparator());
      writeMessage("State of game when quit:" + System.lineSeparator());
      visualizeBoard(model, view);
      return;
    }
  }

  private void visualizeGameOver(SameGameModel<T> model, SameGameTextView view) {
    if (model.gameOver()) {
      writeMessage("Game over." + System.lineSeparator());
      visualizeBoard(model, view);
    }
  }

  private void respondToUserMove(SameGameModel<T> model, Scanner sc, SameGameTextView view) {
    String userMove = "";
    int swapFromCol;
    int removeCol;
    int removeRow;
    int swapFromRow;
    int swapToRow;
    int swapToCol;

    while (!this.quit && !model.gameOver()) {

      try {
        userMove = sc.next();
      }
      catch (Exception e){
        throw new IllegalStateException("Readable failure");
      }

      switch (userMove) {
        case "q":
        case "Q":
          quit = true;
          break;
        case "m":
          try {
            removeRow = this.nextInt(sc) - 1;
            if (this.quit) {
              continue;
            }
            removeCol = this.nextInt(sc) - 1;
            if (this.quit) {
              continue;
            }
            model.removeMatch(removeRow, removeCol);
          } catch (Exception matchE) {
            writeMessage("Invalid move. Try again. " + matchE.getMessage() + System.lineSeparator());
          }
          break;
        case "s":
          swapFromRow = this.nextInt(sc) - 1;
          if (this.quit) {
            continue;
          }
          swapFromCol = this.nextInt(sc) - 1;
          if (this.quit) {
            continue;
          }
          swapToRow = this.nextInt(sc) - 1;
          if (this.quit) {
            continue;
          }
          swapToCol = this.nextInt(sc) - 1;
          if (this.quit) {
            continue;
          }
          try {
            model.swap(swapFromRow, swapFromCol, swapToRow, swapToCol);
          } catch (Exception swapE) {
            writeMessage("Invalid move. Try again. " + swapE.getMessage() + System.lineSeparator());
          }
          break;
        default:
          writeMessage("Invalid command. Try Again. " + userMove + " not allowed.");
      }
      visualizeBoard(model, view);
    }
  }

  private int nextInt(Scanner sc) {
    String item = "";
    int itemInt = -1;
    try {
      item = sc.next();
    }
    catch (Exception e) {
      throw new IllegalStateException("No more elements");
    }
    while (!item.equalsIgnoreCase("q")) {
      try {
        itemInt = Integer.parseInt(item);
      }
      catch (Exception e) {
        System.out.println("Error");
      }
      if (itemInt >= 0) {
        return itemInt;
      } else {
        item = sc.next();
      }
    }
    this.quit = true;
    return -1;
  }

  private void visualizeBoard(SameGameModel<T> model, SameGameTextView view) {
    try {
      view.render();
    } catch (Exception e) {
      throw new IllegalStateException();
    }
    writeMessage("Remaining swaps: " + model.remainingSwaps() + System.lineSeparator());
    writeMessage("Score: " + model.score() + System.lineSeparator());
  }


  @Override
  public void playGame(SameGameModel<T> model, List<List<T>> board, int swaps) throws IllegalStateException {

    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    // start the game
    Scanner sc = new Scanner(this.readable);
    try {
      model.startGame(board, swaps);
    }
    catch (Exception e) {
      throw new IllegalStateException("Game cannot be started");
    }
    SameGameTextView view = new SameGameTextView(model, this.appendable);

    respondToUserMove(model, sc, view);

    visualizeGameOver(model, view);

    visualizeQuit(model, view);

  }

  protected void writeMessage(String message) throws IllegalArgumentException {
    try {
      appendable.append(message);

    } catch (IOException e) {
      throw new IllegalArgumentException(e.getMessage());
    }
  }
}