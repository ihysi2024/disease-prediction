package cs3500.samegame.controller;

import java.util.List;

import cs3500.samegame.model.hw02.SameGameModel;

public class SameGameTextController<T> implements SameGameController<T>{

  public SameGameTextController(Readable rd, Appendable ap) {

  }
  @Override
  public void playGame(SameGameModel<T> model, int rows, int cols, int swaps, boolean isRandom) throws IllegalStateException {

  }

  @Override
  public void playGame(SameGameModel<T> model, List<List<T>> board, int swaps) throws IllegalStateException {

  }
}