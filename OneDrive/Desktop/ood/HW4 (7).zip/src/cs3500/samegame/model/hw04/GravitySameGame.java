package cs3500.samegame.model.hw04;

import java.util.List;

import cs3500.samegame.model.hw02.FourPieceSameGame;
import cs3500.samegame.model.hw02.Piece;
import cs3500.samegame.model.hw02.PieceType;
import cs3500.samegame.model.hw02.SameGameModel;

public class GravitySameGame extends FourPieceSameGame {

  FourPieceSameGame starterGame;

  public GravitySameGame() {
    super();
  }

  @Override
  public void swap(int fromRow, int fromCol, int toRow, int toCol) {
    super.swap(fromRow, fromCol, toRow, toCol);
    gravity();
  }

  @Override
  public void removeMatch(int row, int col) {
    super.removeMatch(row, col);
    gravity();
  }

  private void gravity() {
    boolean leftAbove = true;

    while (leftAbove) {
      leftAbove = false;
      for (int rowNum = 0; rowNum < this.rows - 1; rowNum++) {
        for (int colNum = 0; colNum < this.cols; colNum++) {
          if ((super.board.get(rowNum).get(colNum).color() != PieceType.EMPTY) &&
          (super.board.get(rowNum + 1).get(colNum).color() == PieceType.EMPTY)) {
            leftAbove = true ;
            PieceType color = super.board.get(rowNum).get(colNum).color();
            super.board.get(rowNum + 1).set(colNum,
                    new Piece(color, (rowNum + 1), colNum));
            super.board.get(rowNum).set(colNum,
                    new Piece(PieceType.EMPTY, rowNum, colNum));
          }

        }
      }
    }
  }

  @Override
  public int width() {
    return super.width();
  }

  @Override
  public int length() {
    return super.length();
  }

  @Override
  public Piece pieceAt(int row, int col) {
    return super.pieceAt(row, col);
  }

  @Override
  public int score() {
    return super.score();
  }

  @Override
  public int remainingSwaps() {
    return super.remainingSwaps();
  }

  @Override
  public boolean gameOver() {
    return super.gameOver();
  }

  @Override
  public void startGame(int rows, int cols, int swaps, boolean random) {
    super.startGame(rows, cols, swaps, random);
    gravity();
  }

  @Override
  public Piece[] createListOfPieces() {
    return super.createListOfPieces();
  }

  @Override
  public void startGame(List<List<Piece>> board, int swaps) {
    super.startGame(board, swaps);
    gravity();
  }
}
