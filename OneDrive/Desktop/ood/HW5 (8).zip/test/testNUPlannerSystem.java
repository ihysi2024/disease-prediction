import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import model.Event;
import model.NUPlanner;
import model.Schedule;
import model.Time;
import model.User;

public class testNUPlannerSystem {

  private Event newMorningLec;
  private Event morningLec;
  private Event morningLecOverlapping;
  private Event morningLecSameTime;
  private Event morningLecEndTime;
  private Event morningSnack;

  private Event afternoonLec;
  private Event officeHours;

  private Event sleep;

  private Schedule luciaSchedule;

  private Schedule studentAnonSchedule;

  private Schedule chatSchedule;

  private Schedule emptySchedule;

  private User profLuciaUser;

  private User studentAnonUser;

  private User chatUser;
  private NUPlanner plannerSystem;
  private HashMap<String, String[]> morningLecMap;


  @Before
  public void setUp() {

    this.emptySchedule = new Schedule(new ArrayList<>());

    this.profLuciaUser = new User("Prof Lucia", emptySchedule);
    this.studentAnonUser = new User("Student Anon", emptySchedule);
    this.chatUser = new User("Chat", emptySchedule);

    this.morningLec = new Event("CS3500 Morning Lecture",
            new Time( Time.Day.TUESDAY, 9, 50),
            new Time(Time.Day.TUESDAY, 00, 01),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));



    this.newMorningLec = new Event("CS3500 Morning Lecture",
            new Time( Time.Day.TUESDAY, 13, 35),
            new Time(Time.Day.TUESDAY, 16, 00),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));


    // same time as the morning lecture
    this.morningLecSameTime = new Event("same time morning lecture",
            new Time( Time.Day.TUESDAY, 9, 50),
            new Time(Time.Day.TUESDAY, 11, 30),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList(
                    "Student Anon")));

    // overlapping time as the morning lecture
    this.morningLecOverlapping = new Event("overlapping morning lecture ",
            new Time( Time.Day.TUESDAY, 8, 30),
            new Time(Time.Day.TUESDAY, 10, 30),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));

    // start time same as end time of morning lecture
    this.morningLecEndTime = new Event("same start time as end time",
            new Time( Time.Day.TUESDAY, 11, 30),
            new Time(Time.Day.TUESDAY, 12, 15),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));

    // same time as the morning lecture
    this.morningLecSameTime = new Event("same time morning lecture",
            new Time( Time.Day.TUESDAY, 9, 50),
            new Time(Time.Day.TUESDAY, 11, 30),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));

    // overlapping time as the morning lecture
    this.morningLecOverlapping = new Event("overlapping morning lecture ",
            new Time( Time.Day.TUESDAY, 8, 30),
            new Time(Time.Day.TUESDAY, 10, 30),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));

    // start time same as end time of morning lecture
    this.morningLecEndTime = new Event("same start time as end time",
            new Time( Time.Day.TUESDAY, 11, 30),
            new Time(Time.Day.TUESDAY, 12, 15),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));

    this.afternoonLec = new Event("CS3500 Afternoon Lecture",
            new Time(Time.Day.TUESDAY, 13, 35),
            new Time(Time.Day.TUESDAY, 15, 15),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Chat")));

    this.sleep = new Event("Sleep",
            new Time(Time.Day.FRIDAY, 18, 0),
            new Time(Time.Day.SUNDAY, 12, 0),
            true,
            "Home",
            new ArrayList<>(Arrays.asList("Prof. Lucia")));

    this.luciaSchedule = new Schedule(new ArrayList<>(Arrays.asList(morningLec, afternoonLec, sleep)));
    this.studentAnonSchedule = new Schedule(new ArrayList<>(Arrays.asList(morningLec)));
    this.chatSchedule = new Schedule(new ArrayList<>(Arrays.asList(morningLec, afternoonLec)));

    this.profLuciaUser = new User("Prof. Lucia", luciaSchedule);
    this.studentAnonUser = new User("Student Anon", studentAnonSchedule);
    this.chatUser = new User("Chat", chatSchedule);

    this.morningSnack = new Event("snack",
            new Time(Time.Day.TUESDAY, 8, 30),
            new Time(Time.Day.TUESDAY, 8, 45),
            false,
            "Churchill Hall 101",
            List.of("Student Anon"));

    this.officeHours = new Event("office hours",
            new Time(Time.Day.THURSDAY, 15, 15),
            new Time(Time.Day.THURSDAY, 16, 30),
            false,
            "Churchill Hall 101",
            List.of("Student Anon",
                    "Prof. Lucia"));

    HashSet<User> users = new HashSet<User>();
    users.add(this.profLuciaUser);
    users.add(this.studentAnonUser);
    users.add(this.chatUser);
    this.plannerSystem = new NUPlanner(users);
  }

  /**
   * Test the observational methods - getUsers()
   */

  @Test
  public void testObservationalMethods() {
    HashSet<User> usersCompare = new HashSet<User>();
    usersCompare.add(this.profLuciaUser);
    usersCompare.add(this.studentAnonUser);
    usersCompare.add(this.chatUser);
    Assert.assertEquals(3, this.plannerSystem.getUsers().size());
    Assert.assertEquals(usersCompare, this.plannerSystem.getUsers());
  }

  /**
   * Test that a user can retrieve a set of events occurring at a certain time correctly
   */
  @Test
  public void testRetrieveUserScheduleAtTime() {
    // event starting at the given time
    Assert.assertEquals(List.of(this.afternoonLec),
            this.plannerSystem.retrieveUserScheduleAtTime(profLuciaUser,
                    new Time(Time.Day.TUESDAY, 13, 35)));

    // event starting before the given time but ending after
    Assert.assertEquals(List.of(this.afternoonLec),
            this.plannerSystem.retrieveUserScheduleAtTime(profLuciaUser,
                    new Time(Time.Day.TUESDAY, 14, 15)));

    // no event occurring at the time
    Assert.assertEquals(List.of(),
            this.plannerSystem.retrieveUserScheduleAtTime(profLuciaUser,
                    new Time(Time.Day.THURSDAY, 14, 15)));

    plannerSystem.addEventForRelevantUsers(this.officeHours);

    // an event starting at that time and ending at that time
    Assert.assertEquals(List.of(this.afternoonLec, this.officeHours),
            this.plannerSystem.retrieveUserScheduleAtTime(profLuciaUser,
                    new Time(Time.Day.TUESDAY, 15, 15)));

  }

  @Test
  public void testAddEvent() {
    //System.out.println(this.studentAnonUser.getSchedule().getEvents().size());

    plannerSystem.addEventForRelevantUsers(this.officeHours);
    //Assert.assertTrue(this.profLuciaUser.getSchedule().getEvents().contains(this.officeHours));
    //Assert.assertTrue(this.studentAnonUser.getSchedule().getEvents().contains(this.officeHours));
    //Assert.assertFalse(this.chatUser.getSchedule().getEvents().contains(this.officeHours));

   // System.out.println(this.studentAnonUser.getSchedule().getEvents().size());

    plannerSystem.addEventForRelevantUsers(this.morningSnack);

    //System.out.println(this.studentAnonUser.getSchedule().getEvents().size());


    Assert.assertFalse(this.profLuciaUser.getSchedule().getEvents().contains(this.morningSnack));
    Assert.assertTrue(this.studentAnonUser.getSchedule().getEvents().contains(this.morningSnack));
    Assert.assertFalse(this.chatUser.getSchedule().getEvents().contains(this.morningSnack));
  }

  @Test
  public void testModifyEvent() {
    Event newOfficeHours = new Event("office hours",
            new Time(Time.Day.WEDNESDAY, 15, 15),
            new Time(Time.Day.WEDNESDAY, 16, 30),
            false,
            "Churchill Hall 101",
            List.of("Student Anon",
                    "Prof. Lucia"));

    System.out.println("BEFORE ADDING: " + studentAnonUser.getSchedule().getEvents().size());
    plannerSystem.addEventForRelevantUsers(this.officeHours);
    System.out.println("AFTER ADDING: " + studentAnonUser.getSchedule().getEvents().size());
    plannerSystem.removeEventForRelevantUsers(this.officeHours, studentAnonUser);
    System.out.println("AFTER REMOVING: " + studentAnonUser.getSchedule().getEvents().size());
    plannerSystem.addEventForRelevantUsers(newOfficeHours);
    System.out.println("AFTER ADDING: " + studentAnonUser.getSchedule().getEvents().size());
    plannerSystem.modifyEvent(this.officeHours, newOfficeHours);

    Assert.assertEquals(List.of(newOfficeHours),
            plannerSystem.retrieveUserScheduleAtTime(studentAnonUser,
                    new Time(Time.Day.WEDNESDAY, 15, 15)));
  }




}


