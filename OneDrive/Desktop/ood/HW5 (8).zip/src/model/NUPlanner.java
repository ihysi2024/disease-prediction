package model;

import org.xml.sax.SAXException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;

import static model.User.interpretXML;

/**
 * Planner system that contains a set of users and their corresponding schedules
 */
public class NUPlanner implements PlannerSystem {

  /**
   * Planner system that contains a list of users and their corresponding schedules.
   * Assumptions to be made is that all users that will ever be invited to an event
   * are already in the system and that every user has exactly one schedule. Duplicate
   * users cannot be added to the system by the inclusion of a set of users
   * instead of a list.
   */
  private final Set<User> users;

  /**
   * Initialize a planner system with a given set of users
   *
   * @param users non-duplicate user list in the system
   */
  public NUPlanner(Set<User> users) {
    this.users = new HashSet<>(users);
  }

  /**
   * Initialize a planner system with an empty list of users.
   */
  public NUPlanner() {
    this.users = new HashSet<>();
  }

  /**
   * Observe the users in the system.
   * @return a set of users
   */

  public Set<User> getUsers() {
    return this.users;
  }

  @Override
  public void exportScheduleAsXML(Schedule schedule) {

  }

  /**
   * return events in a user's schedule at a given time
   *
   * @param user      the user to examine
   * @param givenTime the time to look at event within
   * @return a list of events. return at empty list if no events at that time
   * @throws IllegalArgumentException if user doesn't exist or doesn't have a schedule
   */
  @Override
  public List<Event> retrieveUserScheduleAtTime(User user, Time givenTime) {
    return user.getSchedule().eventsOccurring(givenTime);
  }

  /**
   * Return events in a user's schedule occurring at a given time.
   *
   * @param user the user to examine
   * @return the specified user's schedule
   * @throws IllegalArgumentException if user doesn't exist or doesn't have a schedule
   */
  @Override
  public Schedule retrieveFullUserSchedule(User user) {
    return null;
  }


  /**
   * Add events for the users listed in the event's invitee list
   *
   * @param eventToAdd event to add to the relevant user schedule
   */
  public void addEventForRelevantUsers(Event eventToAdd) {
    Iterator<User> iterUsers = this.users.iterator();
    Set<User> newUsers = new HashSet<>();
    while (iterUsers.hasNext()) {
      User currUser = iterUsers.next();
      ArrayList<Event> currUserEvent = new ArrayList<>();
      currUserEvent.addAll(currUser.getSchedule().getEvents());
      Schedule currUserSchedule = new Schedule(currUserEvent);
      if (eventToAdd.getUsers().contains(currUser.getName())) {
        try {
          System.out.println(currUser.getName());
          System.out.println(currUserSchedule.getEvents().size());
          currUserSchedule.addEvent(eventToAdd);
          System.out.println(currUserSchedule.getEvents().size());
          User replaceUser = new User(currUser.getName(), currUserSchedule);
          currUser.updateSchedule(currUserSchedule);
          newUsers.add(replaceUser);
        }
        catch (IllegalArgumentException e) {
          // event is not added because it overlaps
        }
      }
    }

    updateUsers(newUsers);
  }

  private void updateUsers(Set<User> newUsers) {
    List<String> newNames = new ArrayList<>();
    for (User newUser: newUsers) {
      newNames.add(newUser.getName());
    }
    List<User> userToUpdate = new ArrayList<>();
    for (User user: this.users) {
      if (newNames.contains(user.getName())) {
        userToUpdate.add(user);
      }
    }
    for (User user: userToUpdate) {
      this.users.remove(user);
    }
    for (User user: newUsers) {
      this.users.add(user);
    }
  }

  /**
   * Events can only be modified if all users can attend the event.
   * @param prevEvent event to be modified
   * @param newEvent what the previous event should be modified to
   * @throws IllegalArgumentException if user listed cannot attend the modified event
   **/

  public void modifyEvent(Event prevEvent, Event newEvent) {
    User host = null;
    for (User user: this.users) {
      if (user.getName() == prevEvent.getUsers().get(0)) {
        host = new User(user.getName(), user.getSchedule());
      }
    }
    //System.out.println(host.userToString());
    // first try removing the prevEvent and adding the newEvent for every user
    try {
      removeEventForRelevantUsers(prevEvent, host);

      addEventForRelevantUsers(newEvent);

    }
    catch (IllegalArgumentException e) {
      // if an exception is thrown, leave the list of events alone to avoid
      // causing conflict in any user's schedule
    }
  }

  /**
   * Remove an event from planner system for relevant users
   * If host (first user in invitee list) is removing event, remove for all users
   * If any other user, only remove event from their schedule
   *
   * @param eventToRemove event to remove from planner system
   * @param userRemovingEvent user removing the event
   */
  public void removeEventForRelevantUsers(Event eventToRemove, User userRemovingEvent) {
    Iterator<User> iterUsers = this.users.iterator();
    Set<User> newUsers = new HashSet<>();
    // user trying to remove an event is the host
    if (userRemovingEvent.getName().equals(eventToRemove.getUsers().get(0))) {
      while (iterUsers.hasNext()) {
        User currUser = iterUsers.next();
        ArrayList<Event> currUserEvent = new ArrayList<>();
        currUserEvent.addAll(currUser.getSchedule().getEvents());
        Schedule currUserSchedule = new Schedule(currUserEvent);
        if (eventToRemove.getUsers().contains(currUser.getName())) {
          try {
            currUserSchedule.removeEvent(eventToRemove);
            User replaceUser = new User(currUser.getName(), currUserSchedule);
            currUser.updateSchedule(currUserSchedule);
            newUsers.add(replaceUser);
          }
          // given event is not in schedule
          catch (IllegalArgumentException e) {
          }
        }
      }
    }
    // just an invitee trying to remove an event
    else {
      ArrayList<Event> inviteeEvents = new ArrayList<>();
      for (Event event: userRemovingEvent.getSchedule().getEvents()) {
        inviteeEvents.add(event);
      }
      Schedule inviteeSched = new Schedule(inviteeEvents);
      inviteeSched.removeEvent(eventToRemove);
      userRemovingEvent.updateSchedule(inviteeSched);
    }
    updateUsers(newUsers);

    //System.out.println(userRemovingEvent.getSchedule().getEvents().size());
  }


}
