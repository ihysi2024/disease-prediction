package model;

public interface IUser {

  public String getName();

  // public Schedule getSchedule();
}
