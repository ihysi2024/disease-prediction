import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import cs3500.samegame.model.hw02.FourPieceSameGame;
import cs3500.samegame.model.hw04.GravitySameGame;
import cs3500.samegame.model.hw02.Piece;
import cs3500.samegame.model.hw02.PieceType;
import cs3500.samegame.view.SameGameTextView;

/**
 * Represents tests for GravitySameGame.
 */

public class GravitySameGameTest extends FourPieceSameGameTest{
  FourPieceSameGame fpsgRandom;
  FourPieceSameGame fpsgDeterm;
  FourPieceSameGame fpsgRandomSmall;
  FourPieceSameGame fpsgDetermSmall;
  List<List<Piece>> allPieces;

  SameGameTextView sgvRandom;
  SameGameTextView sgvDeterm;

  SameGameTextView sgvRandomSmall;

  SameGameTextView sgvDetermSmall;
  List<List<Piece>> determRows;

  FourPieceSameGame fpsgOneVFour;
  List<Piece> row2;
  List<Piece> row1;
  GravitySameGame gsgDetermSmall;
  GravitySameGame gsgRandomSmall;
  GravitySameGame gsgDeterm;
  GravitySameGame gsgRandom;

  /**
   * Allows a standard set of models to be generated freshly for each test.
   */
  @Before
  public void setUp() {
    this.allPieces  = new ArrayList<>();
    this.fpsgOneVFour = new FourPieceSameGame(this.allPieces, 1, 4, 2, 0);
    this.fpsgRandomSmall = new FourPieceSameGame(this.allPieces, 5,7, 2, 0);
    this.fpsgDetermSmall = new FourPieceSameGame(this.allPieces, 5, 7, 2, 0);
    this.fpsgRandom = new FourPieceSameGame(this.allPieces, 8, 9, 2, 0);
    this.fpsgDeterm = new FourPieceSameGame(this.allPieces, 8, 9, 2, 0);
    this.sgvRandom = new SameGameTextView(this.fpsgRandom);
    this.sgvDeterm = new SameGameTextView(this.fpsgDeterm);
    this.sgvRandomSmall = new SameGameTextView(this.fpsgRandomSmall);
    this.sgvDetermSmall = new SameGameTextView(this.fpsgDetermSmall);

    this.determRows = new ArrayList();
    this.row1 = new ArrayList<>();
    this.row1.add(new Piece(PieceType.RED, 0,0));
    this.row1.add(new Piece(PieceType.RED, 0,1));
    this.row1.add(new Piece(PieceType.BLUE, 0,2));
    this.row1.add(new Piece(PieceType.RED, 0,3));
    this.row1.add(new Piece(PieceType.RED, 0,4));
    this.row2 = new ArrayList();
    this.row2.add(new Piece(PieceType.BLUE, 1,0));
    this.row2.add(new Piece(PieceType.RED, 1,1));
    this.row2.add(new Piece(PieceType.BLUE, 1,2));
    this.row2.add(new Piece(PieceType.YELLOW, 1,3));
    this.row2.add(new Piece(PieceType.RED, 1,4));
    this.determRows.add(this.row1);
    this.determRows.add(this.row2);
    this.gsgDetermSmall = new GravitySameGame();
    this.gsgRandomSmall = new GravitySameGame();
  }

  /**
   * Tests valid gravity functionality at the start of the game.
   */
  @Test
  public void testGravityStartGame() {
    List<List<Piece>> allP = exampleList();

    this.gsgDetermSmall.startGame(allP, 2);

    Assert.assertEquals(null, this.gsgDetermSmall.pieceAt(0, 2));
    Assert.assertEquals(null, this.gsgDetermSmall.pieceAt(1, 2));
    Assert.assertEquals(PieceType.BLUE, this.gsgDetermSmall.pieceAt(2, 2).color());
    Assert.assertEquals(PieceType.GREEN, this.gsgDetermSmall.pieceAt(3, 2).color());
    Assert.assertEquals(PieceType.GREEN, this.gsgDetermSmall.pieceAt(3, 3).color());
    Assert.assertEquals(PieceType.GREEN, this.gsgDetermSmall.pieceAt(4, 4).color());
    Assert.assertEquals(null, this.gsgDetermSmall.pieceAt(2, 3));
  }

  /**
   * Tests valid gravity functionality after removing a block.
   */
  @Test
  public void testGravityRemove() {
    List<List<Piece>> allP = exampleList();

    this.gsgDetermSmall.startGame(allP, 2);

    Assert.assertEquals(PieceType.GREEN, this.gsgDetermSmall.pieceAt(0, 1).color());
    Assert.assertEquals(PieceType.RED, this.gsgDetermSmall.pieceAt(1, 1).color());

    this.gsgDetermSmall.removeMatch(4, 0);

    Assert.assertEquals(null, this.gsgDetermSmall.pieceAt(4,0));
    Assert.assertEquals(null, this.gsgDetermSmall.pieceAt(0, 1));
    Assert.assertEquals(PieceType.GREEN, this.gsgDetermSmall.pieceAt(1, 1).color());
    Assert.assertEquals(PieceType.RED, this.gsgDetermSmall.pieceAt(2, 1).color());

  }

  /**
   * Tests correct extension of FourPieceSameGame width()
   */

  @Test
  public void testGravityWidth() {
    super.testWidth();
  }

  /**
   * Tests correct extension of FourPieceSameGame length().
   */

  @Test
  public void testGravityLength() {
    super.testLength();
  }

  /**
   * Tests correct extension of FourPieceSameGame pieceAt();
   */

  @Test
  public void testGravityPieceAt() {
    super.testPieceAt();
  }

  /**
   * Tests correct extension of FourPieceSameGame remainingSwaps();
   */
  @Test
  public void testGravitySwaps() {
    super.testRemainingSwaps();
  }

  /**
   * Tests correct extension of FourPieceSameGame gameOver();
   */
  @Test
  public void testGravityEmpty() {
    super.testBoardEmpty();
  }

  /**
   * Tests correct extension of FourPieceSameGame createListofPieces();
   */
  @Test
  public void testCreateListPieces() {
    super.testCreateListPieces();
  }

  /**
   * Tests correct extension of base board initialization and game start.
   */
  @Test
  public void testInvalidBoard() {
    super.testInvalidBoard();
  }

  /**
   * Tests correct extension of base board initialization and game start.
   */
  @Test
  public void testGravityDeterm() {
    super.testDetermBoard();
  }

  /**
   * Tests correct extension of base board initialization and game start.
   */
  @Test
  public void testGravityRandom() {
    super.testRandomBoard();
  }

  /**
   * Tests correct extension of base board initialization and game start.
   */

  @Test
  public void testConvenientStartGame() {
    super.testConvenientStartGame();
  }

  /**
   * Tests correct extension of base board initialization and game start.
   */
  @Test
  public void testStartGame() {
    super.testStartGame();
  }
  private static List<List<Piece>> exampleList() {

    Piece e = new Piece(PieceType.EMPTY, 0, 0);
    Piece r = new Piece(PieceType.RED, 0, 0);
    Piece g = new Piece(PieceType.GREEN, 0, 0);
    Piece b = new Piece(PieceType.BLUE, 0, 0);
    Piece y = new Piece(PieceType.YELLOW, 0, 0);
    List<Piece> r1 = Arrays.asList(e, g, b, e, e, e, e);
    List<Piece> r2 = Arrays.asList(e, r, g, e, e, g, b);
    List<Piece> r3 = Arrays.asList(e, y, e, g, b, y, g);
    List<Piece> r4 = Arrays.asList(r, r, e, e, g, b, y);
    List<Piece> r5 = Arrays.asList(r, g, b, y, e, g, b);
    List<List<Piece>> allP = Arrays.asList(r1, r2, r3, r4, r5);

    return allP;
  }

  /**
   * Tests full end-to-end game session of GravitySameGame.
   */
  @Test
  public void testPlayGravityGame() {
    List<List<Piece>> allP = exampleList();

    SameGameTextView<Piece> view = new SameGameTextView<Piece>(this.gsgDetermSmall, new StringBuilder());
    this.gsgDetermSmall.startGame(allP, 2);

    Assert.assertEquals(null, this.gsgDetermSmall.pieceAt(0, 2));
    Assert.assertEquals(null, this.gsgDetermSmall.pieceAt(1, 2));
    Assert.assertEquals(null, this.gsgDetermSmall.pieceAt(2, 3));

    this.gsgDetermSmall.removeMatch(4, 0);
    Assert.assertEquals(null, this.gsgDetermSmall.pieceAt(4, 0));
    Assert.assertEquals(null, this.gsgDetermSmall.pieceAt(3, 0));
    Assert.assertEquals(PieceType.YELLOW, this.gsgDetermSmall.pieceAt(3, 1).color());

    this.gsgDetermSmall.swap(4, 4, 3, 4);
    this.gsgDetermSmall.swap(4, 5, 3, 5);
    this.gsgDetermSmall.removeMatch(3, 2);

    Assert.assertEquals(null, this.gsgDetermSmall.pieceAt(3, 3));
    Assert.assertEquals(null, this.gsgDetermSmall.pieceAt(3, 4));
    Assert.assertEquals(PieceType.BLUE, this.gsgDetermSmall.pieceAt(3, 2).color());
    Assert.assertEquals(PieceType.YELLOW, this.gsgDetermSmall.pieceAt(3, 5).color());

    Assert.assertThrows(NullPointerException.class, () -> this.gsgDeterm.swap(0, 0, 0, 3));

    Assert.assertEquals(3, this.gsgDetermSmall.score());
    Assert.assertEquals(0, this.gsgDetermSmall.remainingSwaps());

    Assert.assertFalse(this.gsgDetermSmall.gameOver());
    this.gsgDetermSmall.removeMatch(4, 4);
    Assert.assertEquals(null, this.gsgDetermSmall.pieceAt(4, 4));
    Assert.assertEquals(PieceType.YELLOW, this.gsgDetermSmall.pieceAt(4, 5).color());
    Assert.assertEquals(PieceType.YELLOW, this.gsgDetermSmall.pieceAt(4, 6).color());

    Assert.assertTrue(this.gsgDetermSmall.gameOver());
  }
}

