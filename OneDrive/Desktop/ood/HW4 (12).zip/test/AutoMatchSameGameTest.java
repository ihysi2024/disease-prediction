import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import cs3500.samegame.model.hw02.FourPieceSameGame;
import cs3500.samegame.model.hw02.Piece;
import cs3500.samegame.model.hw02.PieceType;
import cs3500.samegame.model.hw04.AutoMatchSameGame;
import cs3500.samegame.view.SameGameTextView;

/**
 * Tests the functionality of AutoMatchSameGame
 */
public class AutoMatchSameGameTest extends FourPieceSameGameTest {
  FourPieceSameGame fpsgRandom;
  FourPieceSameGame fpsgDeterm;
  FourPieceSameGame fpsgRandomSmall;
  FourPieceSameGame fpsgDetermSmall;
  List<List<Piece>> allPieces;

  SameGameTextView sgvRandom;
  SameGameTextView sgvDeterm;

  SameGameTextView sgvRandomSmall;

  SameGameTextView sgvDetermSmall;
  List<List<Piece>> determRows;

  FourPieceSameGame fpsgOneVFour;
  List<Piece> row2;
  List<Piece> row1;

  AutoMatchSameGame autoDetermSmall;
  AutoMatchSameGame autoRandomSmall;
  /**
   * Allows a standard set of models to be generated freshly for each test.
   */
  @Before
  public void setUp() {
    this.allPieces  = new ArrayList<>();
    this.fpsgOneVFour = new FourPieceSameGame(this.allPieces, 1, 4, 2, 0);
    this.fpsgRandomSmall = new FourPieceSameGame(this.allPieces, 5,7, 2, 0);
    this.fpsgDetermSmall = new FourPieceSameGame(this.allPieces, 5, 7, 2, 0);
    this.fpsgRandom = new FourPieceSameGame(this.allPieces, 8, 9, 2, 0);
    this.fpsgDeterm = new FourPieceSameGame(this.allPieces, 8, 9, 2, 0);
    this.sgvRandom = new SameGameTextView(this.fpsgRandom);
    this.sgvDeterm = new SameGameTextView(this.fpsgDeterm);
    this.sgvRandomSmall = new SameGameTextView(this.fpsgRandomSmall);
    this.sgvDetermSmall = new SameGameTextView(this.fpsgDetermSmall);

    this.determRows = new ArrayList();
    this.row1 = new ArrayList<>();
    this.row1.add(new Piece(PieceType.RED, 0,0));
    this.row1.add(new Piece(PieceType.RED, 0,1));
    this.row1.add(new Piece(PieceType.BLUE, 0,2));
    this.row1.add(new Piece(PieceType.RED, 0,3));
    this.row1.add(new Piece(PieceType.RED, 0,4));
    this.row2 = new ArrayList();
    this.row2.add(new Piece(PieceType.BLUE, 1,0));
    this.row2.add(new Piece(PieceType.RED, 1,1));
    this.row2.add(new Piece(PieceType.BLUE, 1,2));
    this.row2.add(new Piece(PieceType.YELLOW, 1,3));
    this.row2.add(new Piece(PieceType.RED, 1,4));
    this.determRows.add(this.row1);
    this.determRows.add(this.row2);
    this.autoDetermSmall = new AutoMatchSameGame();
    this.autoRandomSmall = new AutoMatchSameGame();
  }

  /**
   * Tests correct extension of FourPieceSameGame width()
   */

  @Test
  public void testGravityWidth() {
    super.testWidth();
  }

  /**
   * Tests correct extension of FourPieceSameGame length().
   */

  @Test
  public void testGravityLength() {
    super.testLength();
  }

  /**
   * Tests correct extension of FourPieceSameGame pieceAt();
   */

  @Test
  public void testGravityPieceAt() {
    super.testPieceAt();
  }

  /**
   * Tests correct extension of FourPieceSameGame remainingSwaps();
   */
  @Test
  public void testGravitySwaps() {
    super.testRemainingSwaps();
  }

  /**
   * Tests correct extension of FourPieceSameGame gameOver();
   */
  @Test
  public void testGravityEmpty() {
    super.testBoardEmpty();
  }

  /**
   * Tests correct extension of FourPieceSameGame createListofPieces();
   */
  @Test
  public void testCreateListPieces() {
    super.testCreateListPieces();
  }

  /**
   * Tests correct extension of base board initialization and game start.
   */
  @Test
  public void testInvalidBoard() {
    super.testInvalidBoard();
  }

  /**
   * Tests correct extension of base board initialization and game start.
   */
  @Test
  public void testGravityDeterm() {
    super.testDetermBoard();
  }

  /**
   * Tests correct extension of base board initialization and game start.
   */
  @Test
  public void testGravityRandom() {
    super.testRandomBoard();
  }

  /**
   * Tests correct extension of base board initialization and game start.
   */

  @Test
  public void testConvenientStartGame() {
    super.testConvenientStartGame();
  }

  /**
   * Tests correct extension of base board initialization and game start.
   */
  @Test
  public void testStartGame() {
    super.testStartGame();
  }

  private static List<List<Piece>> exampleList() {

    Piece e = new Piece(PieceType.EMPTY, 0, 0);
    Piece r = new Piece(PieceType.RED, 0, 0);
    Piece g = new Piece(PieceType.GREEN, 0, 0);
    Piece b = new Piece(PieceType.BLUE, 0, 0);
    Piece y = new Piece(PieceType.YELLOW, 0, 0);
    List<Piece> r1 = Arrays.asList(e, g, b, e, e, e,e);
    List<Piece> r2 = Arrays.asList(e, r, b, b, e, g, b);
    List<Piece> r3 = Arrays.asList(e, y, r, b, b, y, g);
    List<Piece> r4 = Arrays.asList(r, r, r, r, g, b, y);
    List<Piece> r5 = Arrays.asList(r, g, b, y, e, g, b);
    List<List<Piece>> allP = Arrays.asList(r1, r2, r3, r4, r5);

    return allP;
  }

  /**
   * Test functionality of AutoMatch on post-swap & post-removeMatch board.
   */

  @Test
  public void testValidAutoMatch() {
    List<List<Piece>> allP = exampleList();

    this.autoDetermSmall.startGame(allP, 2);

    // even though a match exists on the board, game start should NOT trigger automatch
    Assert.assertEquals(PieceType.BLUE, this.autoDetermSmall.pieceAt(0, 2).color());
    Assert.assertEquals(PieceType.RED, this.autoDetermSmall.pieceAt(2, 2).color());

    // valid automatch after removeMatch
    this.autoDetermSmall.removeMatch(0, 2);
    Assert.assertEquals(null, this.autoDetermSmall.pieceAt(0, 2));
    Assert.assertEquals(null, this.autoDetermSmall.pieceAt(1, 2));
    Assert.assertEquals(null, this.autoDetermSmall.pieceAt(2, 2));
    Assert.assertEquals(null, this.autoDetermSmall.pieceAt(4, 0));
    Assert.assertEquals(7, this.autoDetermSmall.score());

    // valid automatch after swap
    this.autoDetermSmall.swap(4, 1, 4, 4);
    Assert.assertEquals(null, this.autoDetermSmall.pieceAt(4, 4));
    Assert.assertEquals(null, this.autoDetermSmall.pieceAt(3, 4));
    Assert.assertEquals(null, this.autoDetermSmall.pieceAt(4, 5));
    Assert.assertEquals(8, this.autoDetermSmall.score());
  }

  /**
   * Tests an example of the GravitySameGame game session played till game over.
   */
  @Test
  public void testPlayGravityGame() {
    List<List<Piece>> allP = exampleList();

    SameGameTextView<Piece> view = new SameGameTextView<Piece>(this.autoDetermSmall, new StringBuilder());
    this.autoDetermSmall.startGame(allP, 2);

    Assert.assertEquals(PieceType.BLUE, this.autoDetermSmall.pieceAt(0, 2).color());
    Assert.assertEquals(PieceType.RED, this.autoDetermSmall.pieceAt(3, 0).color());
    Assert.assertEquals(PieceType.RED, this.autoDetermSmall.pieceAt(4, 0).color());

    this.autoDetermSmall.removeMatch(0, 2);
    Assert.assertEquals(null, this.autoDetermSmall.pieceAt(0, 2));
    Assert.assertEquals(null, this.autoDetermSmall.pieceAt(3, 0));
    Assert.assertEquals(null, this.autoDetermSmall.pieceAt(4, 0));

    this.autoDetermSmall.swap(4, 3, 4, 6);
    this.autoDetermSmall.swap(2, 5, 2, 6);

    Assert.assertTrue(this.autoDetermSmall.gameOver());
  }

}
