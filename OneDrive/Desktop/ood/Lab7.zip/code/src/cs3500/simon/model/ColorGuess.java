package cs3500.simon.model;

public enum ColorGuess {
  Red,
  Yellow,
  Green,
  Blue
}
