package cs3500.lab2.offers;

import java.util.List;
import java.util.Objects;

import cs3500.lab2.skills.Skill;

public class Volunteer extends AbstractOffer {
  public Volunteer(String description, List<Skill> reqs) {
    super(description, reqs);
  }

  @Override
  public int calculateSalary() {
    return 0;
  }

  public boolean satisfiesRequirements(List<Skill> application){
    return super.satisfiesRequirements(application);
  }

}
