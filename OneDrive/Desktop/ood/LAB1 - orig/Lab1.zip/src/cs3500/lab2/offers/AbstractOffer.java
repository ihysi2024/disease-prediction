package cs3500.lab2.offers;

import java.util.List;
import java.util.Objects;

import cs3500.lab2.skills.Skill;

abstract public class AbstractOffer implements Offer {
  protected String jobDescription;
  protected List<Skill> requirements;

  AbstractOffer(String jobDescription, List<Skill> requirements){
    this.jobDescription = Objects.requireNonNull(jobDescription);
    this.requirements = Objects.requireNonNull(requirements);
  }

  public abstract int calculateSalary();
  public boolean satisfiesRequirements(List<Skill> application) {
    for(Skill req : requirements) {
      if(!application.stream().anyMatch((appSkill) -> appSkill.satisfiesReq(req))) {
        return false;
      }
    }
    return true;
  }
}