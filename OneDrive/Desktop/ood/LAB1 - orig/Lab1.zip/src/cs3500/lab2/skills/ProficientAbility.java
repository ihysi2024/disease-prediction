package cs3500.lab2.skills;

import java.util.Objects;

public class ProficientAbility extends AbstractSkill{
  private final String ability;

  private final Proficiency proficiency;

  /**
   * describes an ability and its corresponding level of proficiency
   * @param ability
   * @param proficiency
   */
  public ProficientAbility(String ability, Proficiency proficiency){
    Objects.requireNonNull(ability);
    this.ability = ability;
    Objects.requireNonNull(proficiency);
    this.proficiency = proficiency;
  }

  public boolean satisfiesReq(Skill application){
    return super.satisfiesReq(application);
  }

  protected boolean isSatisfiedBy(ProficientAbility other) {
    return other.ability.equals(this.ability) && other.proficiency.equals(this.proficiency);
  }



}
