package cs3500.lab2.skills;

import java.util.List;

/**
 * Represents the number of years of experience.
 * As a requirement, it is satisfied if another Year
 * meets or exceeds the number of years in this skill.
 */
public class Years extends AbstractSkill {

  public int numYears;

  public Years(int y) {
    if (y < 0) {
      throw new IllegalArgumentException("Years cannot be negative");
    }
    this.numYears = y;
  }

  public boolean isSatisfiedBy(Years that) {
    return that.numYears >= this.numYears;
  }

  public boolean satisfiesReq(Skill application){
    return super.satisfiesReq(application);
  }

  protected boolean sameYear(Years other){
    return (this.equals(other));
  }
}
