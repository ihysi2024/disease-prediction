package cs3500.lab2.skills;

import java.util.List;
import java.util.Objects;

public class Ability extends AbstractSkill {

  final String ability;

  public Ability(String ability) {
    Objects.requireNonNull(ability);
    this.ability = ability;
  }

  public boolean satisfiesReq(Skill application){
    return super.satisfiesReq(application);
  }
  @Override
  protected boolean isSatisfiedBy(Ability other) {
    return other.ability.equals(this.ability);
  }

  protected boolean sameYear(Ability other){
    return (this.equals(other));
  }

}
