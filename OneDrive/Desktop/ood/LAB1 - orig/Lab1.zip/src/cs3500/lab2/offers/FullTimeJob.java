package cs3500.lab2.offers;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import cs3500.lab2.skills.Skill;

public class FullTimeJob extends AbstractOffer {

  private int yearlySalary;

  public FullTimeJob(String description, int yearlySalary, List<Skill> reqs) {
    super(description, reqs);
    if(yearlySalary < 0) {
      throw new IllegalArgumentException("Salary cannot be negative");
    }
    this.yearlySalary = yearlySalary;
  }

  public boolean satisfiesRequirements(List<Skill> application){
    return super.satisfiesRequirements(application);
  }

  @Override
  public int calculateSalary() {
    return this.yearlySalary;
  }

}
