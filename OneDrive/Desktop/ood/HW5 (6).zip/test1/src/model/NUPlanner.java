package model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import static model.User.interpretXML;

public class NUPlanner implements PlannerSystem {

  // can't have duplicate users in the NUPlanner system
  /**
   * Planner system that contains a list of users and their corresponding schedules.
   * Assumptions to be made is that all users that will ever be invited to an event
   * are already in the system and that every user has exactly one schedule.
   */
  private final Set<User> users;

  // should this be a HashSet?
  public NUPlanner(Set<User> users) {
    this.users = new HashSet<>(users);
  }
  @Override
  public void parseXMLUpdateSchedule(String filePath) {

  }

  @Override
  public void exportScheduleAsXML(Schedule schedule) {

  }

  /**
   * return events in a user's schedule at a given time
   *
   * @param user      the user to examine
   * @param givenTime the time to look at event within
   * @return a list of events. return at empty list if no events at that time
   * @throws IllegalArgumentException if user doesn't exist or doesn't have a schedule
   */
  @Override
  public List<Event> retrieveUserScheduleAtTime(User user, Time givenTime) {
    return null;
  }

  /**
   * return events in a user's schedule at a given time
   *
   * @param user the user to examine
   * @return the specified user's schedule
   * @throws IllegalArgumentException if user doesn't exist or doesn't have a schedule
   */
  @Override
  public Schedule retrieveFullUserSchedule(User user) {
    return null;
  }


  /**
   * Add events for the users listed in the event's invitee list
   * @param eventToAdd event to add to the relevant user schedule
   */
  public void addEventForRelevantUsers(Event eventToAdd) {
    Iterator<User> iterUsers = this.users.iterator();

    while (iterUsers.hasNext()) {
      User currUser = iterUsers.next();
      System.out.println(currUser.getName());
      if (eventToAdd.getUsers().contains(currUser.getName())) {
        try {
          currUser.getSchedule().addEvent(eventToAdd);
        }
        catch (IllegalArgumentException e) {
          // event is not added because it overlaps
        }
      }
    }
  }

  /**
   * Events can only be modified if all users can attend the event.
   * @throws IllegalArgumentException if user listed cannot attend the modified event
   **/

  public void modifyEvent(Event prevEvent, Event newEvent) {
    User host = null;
    for (User user: this.users) {
      if (user.getName() == prevEvent.getUsers().get(0)) {
        host = new User(user.getName(), user.getSchedule());
      }
    }
    // Iterator<User> prevEventHost = this.users.stream().filter(user. -> prevEvent.getUsers().get(0))
    // first try removing the prevEvent and adding the newEvent for every user
    try {
      removeEventForRelevantUsers(prevEvent, host);
      addEventForRelevantUsers(newEvent);
    }
    catch (IllegalArgumentException e) {
      // if an exception is thrown, leave the list of events alone to avoid
      // causing conflict in any user's schedule
    }
  }

  /**
   * Remove an event from planner system for relevant users
   * If host (first user in invitee list) is removing event, remove for all users
   * If any other user, only remove event from their schedule
   * @param eventToRemove event to remove from planner system
   * @param userRemovingEvent user removing the event
   */
  public void removeEventForRelevantUsers(Event eventToRemove, User userRemovingEvent) {
    Iterator<User> iterUsers = this.users.iterator();

    // user trying to remove an event is the host
    if (userRemovingEvent.getName().equals(eventToRemove.getUsers().get(0))) {
      while (iterUsers.hasNext()) {
        User currUser = iterUsers.next();
        if (eventToRemove.getUsers().contains(currUser.getName())) {
          try {
            currUser.getSchedule().removeEvent(eventToRemove);
          }
          // given event is not in schedule
          catch (IllegalArgumentException e) {
          }
        }
      }
    }
    // just an invitee trying to remove an event
    else {
      userRemovingEvent.getSchedule().removeEvent(eventToRemove);
    }
  }

  public void XMLToSchedule(String filePath) {
    List<Event> eventsToAddToSchedule = interpretXML(filePath);
    for (Event event: eventsToAddToSchedule) {
      this.addEventForRelevantUsers(event);
    }
  }

  /**
   * Schedule to string view must include each user in the planner system
   */

}
