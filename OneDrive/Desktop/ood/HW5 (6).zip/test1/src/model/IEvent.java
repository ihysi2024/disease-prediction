package model;

public interface IEvent {

}
