package model;

public interface ITime {

  /***
   * compare two times
   * return 0 if they are the same time
   * return -1 if this time comes before that time
   * return 1 if this time comes after that time
   * @param refTime
   * @return
   */

  public int compareTimes(Time refTime);

  public int getHours();

  public int getMinutes();

  public Time.Day getDate();
}
