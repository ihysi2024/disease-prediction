package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Event implements IEvent {
  //User host;
  private String eventName;
  private Time startTime;
  private Time endTime;
  private boolean online;
  private String location;
  private List<String> users;

  public Event(String eventName, Time startTime, Time endTime, boolean online, String location,
               List<String> users) {
   // this.host = Objects.requireNonNull(host);
    if ((users == null) || (users.isEmpty())) {
      throw new IllegalArgumentException("Null list of invitees not allowed");
    }
    if ((eventName == null) || (eventName.isEmpty())) {
      throw new IllegalArgumentException("Null event name not allowed");
    }
    if (startTime == null) {
      throw new IllegalArgumentException("Start times cannot be null");
    }
    if (endTime == null) {
      throw new IllegalArgumentException("End time cannot be null");
    }
    if (startTime.compareTimes(endTime) == 0) {
      throw new IllegalArgumentException("Start and end times must be different.");
    }
    this.eventName = eventName;
    this.startTime = startTime;
    this.endTime = endTime;
    this.online = online;
    this.location = location;
    this.users = users;
  }

  public List<String> getUsers() {
    return this.users;
  }

  public Time getStartTime() {
    return this.startTime;
  }


  /**
   * Compare two events to see if their times coincide with each other
   * if the event's start time is the same or after the previous event's end time,
   * the event do not coincide.
   * @param otherEvent event to compare
   * @return true if the two events coincide and false otherwise
   */
  public boolean overlappingEvents(Event otherEvent) {

    // do the events occur at the same time? if so, they overlap
    if ((this.startTime.compareTimes(otherEvent.endTime) == 0)
            || (this.endTime.compareTimes(otherEvent.startTime) == 0)) {
      //System.out.println("start end time same valid");
      return false;
    }
    // do the events start and end times overlap? if so, they overlap
    else if ((this.startTime.compareTimes(otherEvent.endTime) > 0)
            || (this.endTime.compareTimes(otherEvent.startTime) < 0)) {
      //System.out.println("event ends before other event begins");
      return false;
    }
    else {
      return true;
    }
  }


  public boolean equals(Object other) {
    if (!(other instanceof Event)) {
      return false;
    }
    Event that = (Event)other;
    return this.eventName.equals(that.eventName)
            && this.online == that.online
            && (this.endTime.compareTimes(that.endTime) == 0)
            && (this.startTime.compareTimes(that.startTime) == 0)
            && this.location.equals(that.location)
            && this.users.containsAll(that.users)
            && that.users.containsAll(this.users);
  }

  @Override
  public int hashCode() {
    return Objects.hashCode(this.eventName) + Objects.hashCode(this.endTime)
            + Objects.hashCode(this.startTime) + Objects.hashCode(this.online)
            + Objects.hashCode(this.location) + Objects.hashCode(this.users);
  }

  public String eventToString() {
    return "name: " + eventName + "\n"
            + "time: " + startTime.timeToString() + "->"
            + endTime.timeToString() + "\n"
            + "location: " + location + "\n"
            + "online: " + online + "\n"
            + "users: " + String.join("\n", users);
  }
  public static EventBuilder builder(){
    return new EventBuilder();
  }

  public String eventToXMLFormat() {
    StringBuilder eventXML = new StringBuilder();
    eventXML.append("<event>" + "\n");
    eventXML.toString().indent(5);
    eventXML.append("<name>" + this.eventName + "</name>" + "\n");
    eventXML.append("<time>\n");
    eventXML.toString().indent(5);
    timeToXMLFormat(eventXML);
    eventXML.toString().indent(-5);
    eventXML.append("</time>" + "\n");
    eventXML.append("<location>" + "\n");
    eventXML.toString().indent(5);
    eventXML.append("<online>" + this.online + "</online>" + "\n");
    eventXML.append("<place>" + this.location + "</place>" + "\n");
    eventXML.toString().indent(-5);
    eventXML.append("</location>" + "\n");
    eventXML.append("<users>" + "\n");
    eventXML.toString().indent(5);
    usersToXMLFormat(eventXML);
    eventXML.toString().indent(-5);
    eventXML.append("</users>\n");
    eventXML.toString().indent(-5);
    eventXML.append("</event>");

    return eventXML.toString();
  }

  private void timeToXMLFormat(StringBuilder eventXML) {
    eventXML.append("<start-day>" + this.startTime.getDate() + "</start-day>" +"\n");
    eventXML.append("<start>" + this.startTime.getHours() + this.startTime.getMinutes() + "</start>" + "\n");
    eventXML.append("<end-day>" + this.endTime.getDate() + "</end-day>" + "\n");
    eventXML.append("<end>" + this.endTime.getHours() + this.endTime.getMinutes() + "</end>" + "\n");
  }

  private void usersToXMLFormat(StringBuilder eventXML) {
    for (String invitee: this.users) {
      eventXML.append("<uid>" + invitee + "</uid>" + "\n");
    }
  }



  static class EventBuilder {
    private User host;
    private String eventName;
    private Time startTime;
    private Time endTime;
    private boolean online;
    private String location;
    private List<User> users; // make this a set instead?


    public EventBuilder setHost(User newHost) {
      this.host = newHost;
      return this;
    }
    public EventBuilder setName(String newEventName) {
      this.eventName = newEventName;
      return this;
    }

    /**
    public EventBuilder setStartTime(Time newStartTime) {
      this.startTime = new Time(newStartTime.getHours(), newStartTime.getMinutes(), newStartTime.getDate());
      return this;
    }
    public EventBuilder setHost(Time newEndTime) {
      this.endTime = new Time(newEndTime.getHours(), newEndTime.getMinutes(), newEndTime.getDate());
      return this;
    }
    public EventBuilder setHost(boolean newOnline) {
      this.online = newOnline;
      return this;
    }
    public EventBuilder setLocation(String newLocation) {
      this.location = newLocation;
      return this;
    }
    public EventBuilder setUsers(List<User> newUsers) {
      // check not an alias
      List<User> newListUsers = new ArrayList<>();
      for (User user: newUsers) {
        newListUsers.add(new User(user.getName(), user.getSchedule()));
       // newListUsers.add(new User(user.getName()));
      }
      return this;
    }

    //public User getHost() {
     // return new User(this.host.getName(), this.host.getSchedule());
    //}
    public User getHost() {
      return new User(this.host.getName(), this.host.getSchedule());
    }

    public String eventName() {
      return this.eventName;
    }

    public Time getStartTime() {
      return new Time(this.startTime.getHours(), this.startTime.getMinutes(),
              this.startTime.getDate());
    }

    public Time getEndTime() {
      return new Time(this.endTime.getHours(), this.endTime.getMinutes(),
              this.endTime.getDate());
    }

    public boolean getOnline() {
      return this.online;
    }

    public String getLocation() {
      return this.location;
    }

    public List<User> getListUsers() {
      List<User> newListUsers = new ArrayList<>();
      for (User user: this.users) {
       // newListUsers.add(new User(user.getName(), user.getSchedule()));
        newListUsers.add(new User(user.getName(), user.getSchedule()));
      }
      return newListUsers;
    }

     **/



  }
}
