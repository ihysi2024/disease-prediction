package model;

import java.util.List;
import java.util.Objects;

public class Time implements ITime {

  private final int hours;
  private final int minutes;
  private final Day date;

  public enum Day {
    SUNDAY(0, "Sunday"),
    MONDAY(1, "Monday"),
    TUESDAY(2, "Tuesday"),
    WEDNESDAY(3, "Wednesday"),
    THURSDAY(4, "Thursday"),
    FRIDAY(5, "Friday"),
    SATURDAY(6, "Saturday");
    private final int dayIdx;
    private final String dayString;

    Day(int dayIdx, String dayString) {
      this.dayIdx = dayIdx;
      this.dayString = dayString;
    }

    public String getDayString() {
      return dayString;
    }

    public int getDayIdx() {
      return dayIdx;
    }

  }

  public Time (Day date, int hours, int minutes) {
    if (hours < 0 || hours > 24) {
      throw new IllegalArgumentException("Invalid time");
    }
    if (minutes < 0 || minutes > 59) {
      throw new IllegalArgumentException("Invalid time");
    }

    this.hours = hours;
    this.minutes = minutes;
    this.date = date;
  }

  public int getHours() {
    return this.hours;
  }

  public int getMinutes() {
    return this.minutes;
  }

  public Day getDate() {
    return this.date;
  }

  /***
   * compare two times
   * return 0 if they are the same time
   * return -1 if this time comes before that time
   * return 1 if this time comes after that time
   * @param refTime
   * @return
   */

  public int compareTimes(Time refTime) {
    if (this.date.dayIdx < refTime.getDate().dayIdx) {
      return -1;
    }
    else if (this.date.dayIdx > refTime.getDate().dayIdx) {
      return 1;
    }
    else {
      if (this.hours < refTime.getHours()) {
        return -1;
      }
      else if (this.hours > refTime.getHours()) {
        return 1;
      }
      else {
        if (this.minutes < refTime.getMinutes()) {
          return -1;
        }
        else if (this.minutes > refTime.getMinutes()) {
          return 1;
        }
        else {
          return 0;
        }
      }
    }
  }

  /*
  Return the duration of an event in minutes
   *
   * @return

  public int calculateDuration(Time time) {
    int minutes = 0;
    minutes = (this.hours);

  }
   */


  public static Time stringToTime(String day, String time) {
    List<String> daysofTheWeek = List.of("Sunday", "Monday", "Tuesday");
    Day tempDay = Day.SUNDAY;
    int tempHours = 0;
    int tempMin = 0;
    // throw exception if given day isn't in list
    if (!daysofTheWeek.contains(day)) {
      throw new IllegalArgumentException("invalid day");
    }

    for (Day constDay : Day.values()) {
      if (day == constDay.getDayString()) {
        tempDay = constDay;
      }
    }
    if (time.length() != 4) {
      throw new IllegalArgumentException("invalid time input");
    }

    tempHours = Integer.parseInt(String.valueOf(time.charAt(0)) + String.valueOf(time.charAt(1)));
    tempMin = Integer.parseInt(String.valueOf(time.charAt(2)) + String.valueOf(time.charAt(3)));

    if (tempHours > 23 || tempHours < 0) {
      throw new IllegalArgumentException("invalid hours");
    }
    if (tempMin > 60 || tempMin < 0) {
      throw new IllegalArgumentException("invalid minutes");
    }

    return new Time(tempDay, tempHours, tempMin);
  }

  public String timeToString() {
    return this.date.dayString + ": " + this.hours + ":" + this.minutes;
  }

}
