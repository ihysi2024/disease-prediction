import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import model.Event;
import model.Schedule;
import model.Time;
import model.User;

public class testEvent {


  private Event morningLec;
  private Event morningLecOverlapping;
  private Event morningLecSameTime;
  private Event morningLecEndTime;
  private Event afternoonLec;

  private Event afternoonLecOverlapping;
  private Event afternoonLecEndAfter;
  private Event sleep;

  private Schedule emptySchedule;

  private User profLuciaUser;

  private User studentAnonUser;

  private User chatUser;



  @Before
  public void setUp() {
    this.emptySchedule = new Schedule(new ArrayList<>());

    this.profLuciaUser = new User("Prof Lucia", emptySchedule);
    this.studentAnonUser = new User("Student Anon", emptySchedule);
    this.chatUser = new User("Chat", emptySchedule);

    this.morningLec = new Event("CS3500 Morning Lecture",
            new Time( Time.Day.TUESDAY, 9, 50),
            new Time(Time.Day.TUESDAY, 11, 30),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));

    // same time as the morning lecture
    this.morningLecSameTime = new Event("same time morning lecture",
            new Time( Time.Day.TUESDAY, 9, 50),
            new Time(Time.Day.TUESDAY, 11, 30),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));

    // overlapping time as the morning lecture
    this.morningLecOverlapping = new Event("overlapping morning lecture ",
            new Time( Time.Day.TUESDAY, 8, 30),
            new Time(Time.Day.TUESDAY, 10, 30),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));

    // start time same as end time of morning lecture
    this.morningLecEndTime = new Event("same start time as end time",
            new Time( Time.Day.TUESDAY, 11, 30),
            new Time(Time.Day.TUESDAY, 12, 15),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));

    // afternoon lecture
    this.afternoonLec = new Event("CS3500 Afternoon Lecture",
            new Time(Time.Day.TUESDAY, 13, 35),
            new Time(Time.Day.TUESDAY, 15, 15),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Chat")));

    this.afternoonLecOverlapping = new Event("CS3500 Afternoon Lecture",
            new Time(Time.Day.TUESDAY, 14, 30),
            new Time(Time.Day.TUESDAY, 15, 10),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Chat")));

    this.afternoonLecEndAfter = new Event("CS3500 Afternoon Lecture",
            new Time(Time.Day.TUESDAY, 14, 30),
            new Time(Time.Day.TUESDAY, 15, 30),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Chat")));


    // sleep
    this.sleep = new Event("Sleep",
            new Time(Time.Day.FRIDAY, 18, 0),
            new Time(Time.Day.SUNDAY, 12, 0),
            true,
            "Home",
            new ArrayList<>(Arrays.asList("Prof. Lucia")));



  }

  /**
   * Test constructor of an event to ensure correct exceptions thrown for invalid events
   */
  @Test
  public void testStartEndTime() {
    // exactly a week-long event or event has no duration
    Assert.assertThrows(IllegalArgumentException.class, () -> new Event("Meeting",
            new Time(Time.Day.TUESDAY, 13, 00),
            new Time(Time.Day.TUESDAY, 13, 00),
            true, "LA",
            List.of("Prof. Lucia")));


    // end time is null
    Assert.assertThrows(IllegalArgumentException.class, () -> new Event("Meeting",
            new Time(Time.Day.TUESDAY, 13, 00),
            null,
            true, "LA",
            List.of("Prof. Lucia")));

    // start time is null
    Assert.assertThrows(IllegalArgumentException.class, () -> new Event("Meeting",
            null,
            new Time(Time.Day.TUESDAY, 13, 00),
            true, "LA",
            List.of("Prof. Lucia")));

    // there are no invitees/hosts
    Assert.assertThrows(IllegalArgumentException.class, () -> new Event("Meeting",
            new Time(Time.Day.TUESDAY, 13, 00),
            new Time(Time.Day.TUESDAY, 11, 00),
            true, "LA",
            List.of()));

    // null list of invitees/hosts
    Assert.assertThrows(IllegalArgumentException.class, () -> new Event("Meeting",
            new Time(Time.Day.TUESDAY, 13, 00),
            new Time(Time.Day.TUESDAY, 11, 00),
            true, "LA",
            null));

    // the event has no name
    Assert.assertThrows(IllegalArgumentException.class, () -> new Event(null,
            new Time( Time.Day.TUESDAY, 18, 00),
            new Time(Time.Day.TUESDAY, 16, 00),
            true, "LA",
            List.of("Prof. Lucia")));
  }

  /**
   * Test whether overlappingEvents(Event otherEvent) correctly determines whether
   * a given event overlaps with this event
   */

  @Test
  public void testOverlappingEvents() {
    // an event overlaps with itself
    Assert.assertTrue(this.morningLec.overlappingEvents(this.morningLec));
    // an event overlaps with another event at the same time
    Assert.assertTrue(this.morningLec.overlappingEvents(this.morningLecSameTime));
    // an event overlaps with an event that starts before but ends during
    Assert.assertTrue(this.morningLec.overlappingEvents(this.morningLecOverlapping));
    // an event overlaps with an event that starts after this event starts
    // and ends before this event ends
    Assert.assertTrue(this.afternoonLec.overlappingEvents(this.afternoonLecOverlapping));
    // an event overlaps with an event that starts after this event starts
    // and end after this event ends
    Assert.assertTrue(this.afternoonLec.overlappingEvents(this.afternoonLecEndAfter));
    // an event does not overlap with an event that starts when the first event ends
    Assert.assertFalse(this.morningLec.overlappingEvents(this.morningLecEndTime));
    // an event does not overlap with an event that starts after the first event ends
    Assert.assertFalse(this.morningLec.overlappingEvents(this.afternoonLec));
  }

  /**
   * Test that an event can be correctly converted to a string for text view
   */
  @Test
  public void testEventToString() {
    String morningLec = "name: CS3500 Morning Lecture\n" +
            "time: Tuesday: 9:50->Tuesday: 11:30\n" +
            "location: Churchill Hall 101\n" +
            "online: false\n" +
            "users: Prof. Lucia\n" +
            "Student Anon\n" +
            "Chat";
    Assert.assertEquals(morningLec, this.morningLec.eventToString());

    String afternoonLec  = "name: CS3500 Afternoon Lecture\n" +
            "time: Tuesday: 13:35->Tuesday: 15:15\n" +
            "location: Churchill Hall 101\n" +
            "online: false\n" +
            "users: Prof. Lucia\n" +
            "Chat";

    Assert.assertEquals(afternoonLec , this.afternoonLec.eventToString());

  }

  /**
   * Test that an events fields can be correctly tagged for XML exports
   */

  @Test
  public void testEventToXML() {
    String morningLecXML = "<event>\n" +
            "<name>CS3500 Morning Lecture</name>\n" +
            "<time>\n" +
            "<start-day>TUESDAY</start-day>\n" +
            "<start>950</start>\n" +
            "<end-day>TUESDAY</end-day>\n" +
            "<end>1130</end>\n" +
            "</time>\n" +
            "<location>\n" +
            "<online>false</online>\n" +
            "<place>Churchill Hall 101</place>\n" +
            "</location>\n" +
            "<users>\n" +
            "<uid>Prof. Lucia</uid>\n" +
            "<uid>Student Anon</uid>\n" +
            "<uid>Chat</uid>\n" +
            "</users>\n" +
            "</event>";

    Assert.assertEquals(morningLecXML, this.morningLec.eventToXMLFormat());

    String afternoonLecXML = "<event>\n" +
            "<name>CS3500 Afternoon Lecture</name>\n" +
            "<time>\n" +
            "<start-day>TUESDAY</start-day>\n" +
            "<start>1335</start>\n" +
            "<end-day>TUESDAY</end-day>\n" +
            "<end>1515</end>\n" +
            "</time>\n" +
            "<location>\n" +
            "<online>false</online>\n" +
            "<place>Churchill Hall 101</place>\n" +
            "</location>\n" +
            "<users>\n" +
            "<uid>Prof. Lucia</uid>\n" +
            "<uid>Chat</uid>\n" +
            "</users>\n" +
            "</event>";

    Assert.assertEquals(afternoonLecXML, this.afternoonLec.eventToXMLFormat());
  }




  @Test
  public void testAddEvent() {
    // starting schedule - no events yet
    Assert.assertEquals(0, emptySchedule.getEvents().size());
    // add a valid event
    emptySchedule.addEvent(this.morningLec);
    Assert.assertEquals(1, emptySchedule.getEvents().size());

    // adding class at the same time or overlapping time
    Assert.assertThrows(IllegalArgumentException.class,
            () -> emptySchedule.addEvent(this.morningLecSameTime));
    Assert.assertThrows(IllegalArgumentException.class,
            () -> emptySchedule.addEvent(this.morningLecOverlapping));

    // adding class that starts when previous class ends
    emptySchedule.addEvent(this.morningLecEndTime);
    Assert.assertEquals(2, emptySchedule.getEvents().size());
    emptySchedule.addEvent(this.afternoonLec);
    Assert.assertEquals(3, emptySchedule.getEvents().size());
  }



}
