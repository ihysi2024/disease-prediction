package model;

import java.util.ArrayList;
import java.util.Objects;

public class User implements IUser {
  private final String name;

  private Schedule schedule;
  public User(String name, Schedule schedule) {
    this.name = Objects.requireNonNull(name);
    this.schedule = schedule;
  }

  public User(String name) {
    this.name = Objects.requireNonNull(name);
    this.schedule = new Schedule(new ArrayList<>()); // initializing with empty schedule
  }

  public String getName() {
    return this.name;
  }

  public Schedule getSchedule() {
    return this.schedule;
  }

  public String userToString() {
    return "User: " + this.name + "\n" + this.schedule.scheduleToString();
  }
}
