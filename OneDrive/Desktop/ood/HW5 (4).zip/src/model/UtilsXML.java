package model;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

/**
 * An example code file to show how to write to files
 * and read XML files using the built in XML parser.
 *
 * The writing example is simple since not much is needed
 * for it. The reading example shows not only how to read
 * XML and extract information, but also WHY we need to dive
 * really deep: text content at higher levels requires
 * more parsing than it's worth.
 *
 * Written by Lucia A. Nunez, using the tutorial.xml file and based
 * on the tutorial written by Baeldung
 * Source: https://www.baeldung.com/java-xerces-dom-parsing
 *
 * Do NOT simply copy-paste this code into your projects. It's
 * useless in its current form to you. Instead, figure out what it
 * is doing and how, lookup any related Javadocs, and finally write your
 * own wherever you need it.
 */
public class UtilsXML {
  /**
   * Creates an XML file in the directory where this code is run
   * For IntelliJ, that is the project's folder.
   *
   * SIDE-EFFECT: Calling this method twice will OVERWRITE the file.
   * If you want to add to an existing file, use append instead.
   */
  public static void writeToFile() {
    try {
      Writer file = new FileWriter("sample-written.xml");
      file.write("<?xml version=\"1.0\"?>\n");
      file.write("<schedule id=\"You\">");
      file.write("</schedule>");
      file.close();
    } catch (IOException ex) {
      throw new RuntimeException(ex.getMessage());
    }
  }

  /**
   * Reads the specific file, based on the given file path.
   * Prints useful information from the file.
   * For IntelliJ, that is the project's folder.
   */
  public static List<Event> readXML(String filePath) {
    List<HashMap<String, String[]>> listEventsMap = new ArrayList<>();
    List<Event> listEvents = new ArrayList<>();
    try {
      DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
      Document xmlDoc = builder.parse(new File(filePath));
      xmlDoc.getDocumentElement().normalize();

      Node scheduleNode = xmlDoc.getElementsByTagName("schedule").item(0);
     // elem.getAttribute("id") --> somewhere we need this to get the name of the user!!

     // String host = elem.getAttribute("id");
      //This result isn't as nice...
     // System.out.println("Investigating the textContent straight from the outermost element:");
      //System.out.println(scheduleNode.getTextContent());

      //So let's dig deeper into the other elements!
      // looking into each event
      NodeList nodeList = scheduleNode.getChildNodes();
      for (int item = 0; item < nodeList.getLength(); item++) {
        Node current = nodeList.item(item);
        //We need to search for Elements (actual tags) and there
        //is only one: the tutorial tag
        if (current.getNodeType() == Node.ELEMENT_NODE) {
          Element elem = (Element) current;
          //Print out the attributes of this element
          System.out.println("Investigating the attributes:");
          //  System.out.println(elem.getTagName() + " : " + elem.getAttribute("tutId") + " " + elem.getAttribute("type"));
          System.out.println(elem.getTagName());

          //Print out the text that exists inside of this element: it doesn't look pretty...
          //and it erases the other elements
          System.out.println("Investigating the text content inside this element:");
          System.out.println(elem.getTagName() + " : " + elem.getTextContent());

          String tempEventName = "";
          String tempStartDay = "";
          String tempStartTime = "";
          String tempEndDay = "";
          String tempEndTime = "";
          String online = "";
          String location = "";
          List<String> userList = new ArrayList<>();
          HashMap<String, String[]> eventMap = new HashMap<>();
          //... so let's dig even deeper!
          NodeList elemChildren = elem.getChildNodes();
          for (int childIdx = 0; childIdx < elemChildren.getLength(); childIdx++) {

            Node childNode = elemChildren.item(childIdx);
            if (childNode.getNodeType() == Node.ELEMENT_NODE) {
              Element child = (Element) childNode;
              //Now we're getting something more meaningful from each element!
              System.out.println("Investigating the text content inside the innermost tags");
              System.out.println(child.getTagName() + " : " + child.getTextContent());

              String tagName = child.getTagName().trim();


              String[] tagNameChildren = child.getTextContent().trim().split("\n");
              for (int idx = 0; idx < tagNameChildren.length; idx++) {
                tagNameChildren[idx] = tagNameChildren[idx].trim();
              }
              eventMap.put(tagName, tagNameChildren);
            }
          }
          listEventsMap.add(eventMap);
        }

        for (HashMap<String, String[]> eventMap : listEventsMap) {
          listEvents.add(makeEvent(eventMap));
        }
      }
    } catch (ParserConfigurationException ex) {
      throw new IllegalStateException("Error in creating the builder");
    } catch (IOException ioEx) {
      throw new IllegalStateException("Error in opening the file");
    } catch (SAXException saxEx) {
      throw new IllegalStateException("Error in parsing the file");
    }
    return listEvents;
  }

  // grab list of hashmaps - make an event for each hashmap

  public static Event makeEvent(HashMap<String, String[]> eventToMake) {
    String tempEventName = "";

    Time tempStartTime = null;

    Time tempEndTime = null ;
    boolean online = true;
    String location = "";
    List<String> userList = new ArrayList<>();
    for (String key: eventToMake.keySet()) {
      System.out.println(key);
      if (key == "name") {
        tempEventName = eventToMake.get(key)[0];
      }
      if (key == "time") {
        tempStartTime = Time.stringToTime(eventToMake.get(key)[0], eventToMake.get(key)[1]);
        tempEndTime = Time.stringToTime(eventToMake.get(key)[2], eventToMake.get(key)[3]);
      }
      if (key == "location") {
        System.out.println(eventToMake.get(key)[0]);
        online = (eventToMake.get(key)[0].equals("true"));
        System.out.println("*** ONLINE ***" + online);
        location = eventToMake.get(key)[1];
      }
      if (key == "users") {
        userList = Arrays.asList(eventToMake.get(key));
      }
    }
    return new Event(tempEventName, tempStartTime, tempEndTime, online, location, userList);
  }






}
