public interface Features {
  void toggleColor();
  void makeUppercase();
  void restoreLowercase();
  void echoOutput(String typed);
  void exitProgram();
}
