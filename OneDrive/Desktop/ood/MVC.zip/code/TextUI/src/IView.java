public interface IView {
    void showString(String s);
    void showOptions();
    void showStringEntry();
    void showOptionError();
}
