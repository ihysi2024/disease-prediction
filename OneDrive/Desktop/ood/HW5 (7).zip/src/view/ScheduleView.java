package view;

import java.io.IOException;

import model.PlannerSystem;

public interface ScheduleView {
  /**
   * Generate a string text view of each user's schedule
   * @param plannerSystem the planner system to view
   * @return a string of every user's schedule
   * @throws IOException if stringbuilder can't append correctly
   */
  public String plannerSystemString(PlannerSystem plannerSystem) throws IOException;

  /**
   * Appends the text view to an output that can be read.
   * @throws IOException if the planner system text view cannot be properly generated
   */
  public void renderPlanner() throws IOException;
}
