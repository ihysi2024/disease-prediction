import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import cs3500.samegame.model.hw04.FourPieceSameGame;
import cs3500.samegame.model.hw04.GravitySameGame;
import cs3500.samegame.model.hw04.Piece;
import cs3500.samegame.model.hw04.PieceType;
import cs3500.samegame.view.SameGameTextView;

public class GravitySameGameTest {
  FourPieceSameGame fpsgRandom;
  FourPieceSameGame fpsgDeterm;
  FourPieceSameGame fpsgRandomSmall;
  FourPieceSameGame fpsgDetermSmall;
  List<List<Piece>> allPieces;

  SameGameTextView sgvRandom;
  SameGameTextView sgvDeterm;

  SameGameTextView sgvRandomSmall;

  SameGameTextView sgvDetermSmall;
  List<List<Piece>> determRows;

  FourPieceSameGame fpsgOneVFour;
  List<Piece> row2;
  List<Piece> row1;
  GravitySameGame gsgDetermSmall;
  GravitySameGame gsgRandomSmall;
  GravitySameGame gsgDeterm;
  GravitySameGame gsgRandom;

  /**
   * Allows a standard set of models to be generated freshly for each test.
   */
  @Before
  public void setUp() {
    this.allPieces  = new ArrayList<>();
    this.fpsgOneVFour = new FourPieceSameGame(this.allPieces, 1, 4, 2, 0);
    this.fpsgRandomSmall = new FourPieceSameGame(this.allPieces, 5,7, 2, 0);
    this.fpsgDetermSmall = new FourPieceSameGame(this.allPieces, 5, 7, 2, 0);
    this.fpsgRandom = new FourPieceSameGame(this.allPieces, 8, 9, 2, 0);
    this.fpsgDeterm = new FourPieceSameGame(this.allPieces, 8, 9, 2, 0);
    this.sgvRandom = new SameGameTextView(this.fpsgRandom);
    this.sgvDeterm = new SameGameTextView(this.fpsgDeterm);
    this.sgvRandomSmall = new SameGameTextView(this.fpsgRandomSmall);
    this.sgvDetermSmall = new SameGameTextView(this.fpsgDetermSmall);

    this.determRows = new ArrayList();
    this.row1 = new ArrayList<>();
    this.row1.add(new Piece(PieceType.RED, 0,0));
    this.row1.add(new Piece(PieceType.RED, 0,1));
    this.row1.add(new Piece(PieceType.BLUE, 0,2));
    this.row1.add(new Piece(PieceType.RED, 0,3));
    this.row1.add(new Piece(PieceType.RED, 0,4));
    this.row2 = new ArrayList();
    this.row2.add(new Piece(PieceType.BLUE, 1,0));
    this.row2.add(new Piece(PieceType.RED, 1,1));
    this.row2.add(new Piece(PieceType.BLUE, 1,2));
    this.row2.add(new Piece(PieceType.YELLOW, 1,3));
    this.row2.add(new Piece(PieceType.RED, 1,4));
    this.determRows.add(this.row1);
    this.determRows.add(this.row2);
    this.gsgDetermSmall = new GravitySameGame(this.fpsgDetermSmall, 5, 7, 2, 0);
    this.gsgRandomSmall = new GravitySameGame(this.fpsgRandomSmall, 5, 7, 2, 0);
  }

  @Test
  public void testGravityStartGame() {
    ArrayList allP = exampleList();

    this.gsgDetermSmall.startGame(allP, 2);

    Assert.assertEquals(null, this.gsgDetermSmall.pieceAt(0, 2));
    Assert.assertEquals(null, this.gsgDetermSmall.pieceAt(1, 2));
    Assert.assertEquals(PieceType.BLUE, this.gsgDetermSmall.pieceAt(2, 2).color());
    Assert.assertEquals(PieceType.GREEN, this.gsgDetermSmall.pieceAt(3, 2).color());
    Assert.assertEquals(PieceType.GREEN, this.gsgDetermSmall.pieceAt(3, 3).color());
    Assert.assertEquals(PieceType.GREEN, this.gsgDetermSmall.pieceAt(4, 4).color());
    Assert.assertEquals(null, this.gsgDetermSmall.pieceAt(2, 3));
  }

  @Test
  public void testGravityRemove() {
    ArrayList allP = exampleList();

    this.gsgDetermSmall.startGame(allP, 2);

    Assert.assertEquals(PieceType.GREEN, this.gsgDetermSmall.pieceAt(0, 1).color());
    Assert.assertEquals(PieceType.RED, this.gsgDetermSmall.pieceAt(1, 1).color());

    this.gsgDetermSmall.removeMatch(4, 0);

    Assert.assertEquals(null, this.gsgDetermSmall.pieceAt(4,0));
    Assert.assertEquals(null, this.gsgDetermSmall.pieceAt(0, 1));
    Assert.assertEquals(PieceType.GREEN, this.gsgDetermSmall.pieceAt(1, 1).color());
    Assert.assertEquals(PieceType.RED, this.gsgDetermSmall.pieceAt(2, 1).color());

  }

  private static ArrayList exampleList() {
    ArrayList allP = new ArrayList();
    Piece e = new Piece(PieceType.EMPTY, 0, 0);
    Piece r = new Piece(PieceType.RED, 0, 0);
    Piece g = new Piece(PieceType.GREEN, 0, 0);
    Piece b = new Piece(PieceType.BLUE, 0, 0);
    Piece y = new Piece(PieceType.YELLOW, 0, 0);
    ArrayList<Piece> r1 = new ArrayList();
    r1.add(e);
    r1.add(g);
    r1.add(b);
    r1.add(e);
    r1.add(e);
    r1.add(e);
    r1.add(e);
    ArrayList<Piece> r2 = new ArrayList();
    r2.add(e);
    r2.add(r);
    r2.add(g);
    r2.add(e);
    r2.add(e);
    r2.add(g);
    r2.add(b);
    ArrayList<Piece> r3 = new ArrayList();
    r3.add(e);
    r3.add(y);
    r3.add(e);
    r3.add(g);
    r3.add(b);
    r3.add(y);
    r3.add(g);
    ArrayList<Piece> r4 = new ArrayList();
    r4.add(r);
    r4.add(r);
    r4.add(e);
    r4.add(e);
    r4.add(g);
    r4.add(b);
    r4.add(y);
    ArrayList<Piece> r5 = new ArrayList();
    r5.add(r);
    r5.add(g);
    r5.add(b);
    r5.add(y);
    r5.add(e);
    r5.add(g);
    r5.add(b);
    allP.add(r1);
    allP.add(r2);
    allP.add(r3);
    allP.add(r4);
    allP.add(r5);
    return allP;
  }
}

