package cs3500.samegame;

import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import cs3500.samegame.controller.SameGameTextController;
import cs3500.samegame.model.hw04.Piece;
import cs3500.samegame.model.hw04.SameGameCreator;
import cs3500.samegame.model.hw04.SameGameModel;

public final class SameGame {
  public static void main(String[] args) {
    SameGameCreator.GameType type = SameGameCreator.GameType.FOURPIECE;
    int row = 10;
    int cols = 10;
    int swaps = 10;
    boolean random = false;
    List<Integer> inputs = new ArrayList<>();
    inputs.add(row);
    inputs.add(cols);
    inputs.add(swaps);

    if (args[0] == "gravity") {
      type = SameGameCreator.GameType.GRAVITY;
    }
    else if (args[0] == "automatch") {
      type = SameGameCreator.GameType.AUTOMATCH;
    }

    if (args.length > 1) {
      for (int idx = 1; idx < args.length; idx++) {
        try {
          inputs.set((idx-1), Integer.parseInt(args[idx]));
        }
        catch (Exception e) {
          continue;
        }
      }
    }

    SameGameModel<Piece> game = SameGameCreator.createGame(type);
    Readable rd = new InputStreamReader(System.in);
    Appendable ap = new StringBuilder();
    SameGameTextController<Piece> controller = new SameGameTextController<>(rd, ap);
    controller.playGame(game, inputs.get(0), inputs.get(1), inputs.get(2), random);

  }
}
