package cs3500.simon.model;

/**
 * Represents the color in the SimonGame.
 */
public enum ColorGuess {
  Red,
  Yellow,
  Green,
  Blue
}
