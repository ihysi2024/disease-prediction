package view;

import java.io.IOException;
import java.util.HashSet;

import model.NUPlanner;
import model.PlannerSystem;
import model.User;

/**
 * Generate a text view of all users in the planner system to an appendable
 */
public class ScheduleTextView implements ScheduleView {

  PlannerSystem plannerSystem;

  Appendable appendable;

  /**
   * Produce a view for this planner system for all users' schedules to be seen.
   * @param plannerSystem planner system to be viewed
   * @param appendable output view to show the planner system text view on
   */

  public ScheduleTextView(PlannerSystem plannerSystem, Appendable appendable) {
    this.plannerSystem = new NUPlanner();
    this.appendable = appendable;
  }

  /**
   * Generate a string text view of each user's schedule
   * @return a string of every user's schedule
   * @throws IOException if stringbuilder can't append correctly
   */
  public String plannerSystemString() throws IOException {
    StringBuilder planner = new StringBuilder();
    for (User user: this.plannerSystem.getUsers()) {
      planner.append(user.userToString() + "\n");
    }
    return planner.toString();
  }

  /**
   * Appends the text view to an output that can be read.
   * @throws IOException if the planner system text view cannot be properly generated
   */
  public void renderPlanner() throws IOException {
    this.appendable.append(this.plannerSystemString());
  }

}
