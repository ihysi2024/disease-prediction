package model;

import java.util.List;
import java.util.Set;

public interface PlannerSystem {


  /**
   * Export schedule as an XML file
   */

  public void exportScheduleAsXML(String filePath);

  /**
   * return events in a user's schedule at a given time
   * @param user the user to examine
   * @param givenTime the time to look at event within
   * @return a list of events. return at empty list if no events at that time
   * @throws IllegalArgumentException if user doesn't exist or doesn't have a schedule
   */
  public List<Event> retrieveUserScheduleAtTime(User user, Time givenTime);

  /**
   * Is this leaking too much info??
   * return events in a user's schedule
   * @param user the user to examine
   * @return the specified user's schedule
   * @throws IllegalArgumentException if user doesn't exist or doesn't have a schedule
   */
  public Schedule retrieveFullUserSchedule(User user);


  public Set<User> getUsers();

}
