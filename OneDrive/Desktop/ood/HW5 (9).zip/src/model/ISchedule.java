package model;

import java.util.List;

public interface ISchedule {

  /**
   * Add a new event to the events field.
   * @throws IllegalArgumentException if event overlaps another event
   * @param event - the event to be added
   */
  public void addEvent(Event event);

  /**
   * Remove event to the events field.
   * @throws IllegalArgumentException if event doesn't exist
   * @param event - the event to be added
   */

  public void removeEvent(Event event);

  public List<Event> getEvents();
}
