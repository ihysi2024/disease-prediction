import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import model.Event;
import model.Schedule;
import model.Time;
import model.User;

import static model.User.makeEvent;


public class testXML {

  private Event morningLec;
  private Event afternoonLec;

  private Event sleep;

  private Schedule luciaSchedule;

  private Schedule studentAnonSchedule;

  private Schedule chatSchedule;

  private Schedule emptySchedule;

  private User profLuciaUser;

  private User studentAnonUser;

  private User chatUser;
  HashMap<String, String[]> morningLecMap;


  @Before
  public void setUp() {
    this.emptySchedule = new Schedule(new ArrayList<>());

    this.profLuciaUser = new User("Prof Lucia", emptySchedule);
    this.studentAnonUser = new User("Student Anon", emptySchedule);
    this.chatUser = new User("Chat", emptySchedule);

    this.morningLec = new Event("CS3500 Morning Lecture",
            new Time( Time.Day.TUESDAY, 9, 50),
            new Time(Time.Day.TUESDAY, 11, 30),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Student Anon",
                    "Chat")));


    this.afternoonLec = new Event("CS3500 Afternoon Lecture",
            new Time(Time.Day.TUESDAY, 13, 35),
            new Time(Time.Day.TUESDAY, 15, 15),
            false,
            "Churchill Hall 101",
            new ArrayList<>(Arrays.asList("Prof. Lucia",
                    "Chat")));

    this.sleep = new Event("Sleep",
            new Time(Time.Day.FRIDAY, 18, 0),
            new Time(Time.Day.SUNDAY, 12, 0),
            true,
            "Home",
            new ArrayList<>(Arrays.asList("Prof. Lucia")));

    this.luciaSchedule = new Schedule(new ArrayList<>(Arrays.asList(morningLec, afternoonLec, sleep)));
    this.studentAnonSchedule = new Schedule(new ArrayList<>(Arrays.asList(morningLec)));
    this.chatSchedule = new Schedule(new ArrayList<>(Arrays.asList(morningLec, afternoonLec)));

    this.profLuciaUser = new User("Prof Lucia", luciaSchedule);
    this.studentAnonUser = new User("Student Anon", studentAnonSchedule);
    this.chatUser = new User("Chat", chatSchedule);

    this.morningLecMap = new HashMap<>();
    this.morningLecMap.put("name", new String[]{"CS3500 Morning Lecture"});
    this.morningLecMap.put("time", new String[]{"Tuesday", "0950", "Tuesday", "1130"});
    this.morningLecMap.put("location", new String[]{"false", "Churchill Hall 101"});
    this.morningLecMap.put("users", new String[]{"Prof. Lucia", "Student Anon", "Chat"});
  }

  @Test
  public void testReadXML() {

  }

  @Test
  public void testWriteXML() {

  }


}
