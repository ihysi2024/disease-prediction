package model;

public interface IEvent {

  /**
   * Modify all fields of this event
   *
   */
  public void modifyEvent(String fieldName, String changingVal);
}
