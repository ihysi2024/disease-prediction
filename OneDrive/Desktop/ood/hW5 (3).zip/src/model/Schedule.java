package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;

public class Schedule implements ISchedule {
  // private final User scheduleID;
  private final ArrayList<Event> events;


  public Schedule(ArrayList<Event> events) {
   // this.scheduleID = Objects.requireNonNull(scheduleID);
    this.events = Objects.requireNonNull(events);
  }

  /**
   * Add a new event to the events field.
   * @throws IllegalArgumentException if event overlaps another event
   * @param event - the event to be added
   */
  public void addEvent(Event event) {
    int countOverlapping = 0;
    for (Event existingEvent: this.events) {
      if (existingEvent.overlappingEvents(event)) {
        countOverlapping++;
        System.out.println("found overlapping");
      }
      System.out.println(countOverlapping);
    }
    if (countOverlapping != 0) {
      throw new IllegalArgumentException("Event coincides with another event");
    }
    else {
      this.events.add(event);
    }
  }

  /**
   * Remove event to the events field.
   * @throws IllegalArgumentException if event doesn't exist
   * @param otherEvent - the event to be added
   */

  public void removeEvent(Event otherEvent) {
    int scheduleSize = this.events.size();
    this.events.removeIf(thisEvent -> thisEvent.equals(otherEvent));
    if (this.events.size() == scheduleSize) {
      throw new IllegalArgumentException("Event not in schedule");
    }
  }

  public User getScheduleID() {
    return null;
  }

  public List<Event> getEvents() {
    return this.events;
  }

  public HashMap<Time.Day, List<Event>> dayToEventsMappping() {
    HashMap<Time.Day, List<Event>> dayToEvent = new LinkedHashMap<>();
    dayToEvent.put(Time.Day.SUNDAY, new ArrayList<>());
    dayToEvent.put(Time.Day.MONDAY, new ArrayList<>());
    dayToEvent.put(Time.Day.TUESDAY, new ArrayList<>());
    dayToEvent.put(Time.Day.WEDNESDAY, new ArrayList<>());
    dayToEvent.put(Time.Day.THURSDAY, new ArrayList<>());
    dayToEvent.put(Time.Day.FRIDAY, new ArrayList<>());
    dayToEvent.put(Time.Day.SATURDAY, new ArrayList<>());

    for (Event eventToSchedule: this.events) {
      dayToEvent.get(eventToSchedule.getStartTime().getDate()).add(eventToSchedule);
    }
    return dayToEvent;
  }

  public String scheduleToString() {
    StringBuilder scheduleStr = new StringBuilder();
    HashMap<Time.Day, List<Event>> eventsMap = this.dayToEventsMappping();
    for (Time.Day dayOfTheWeek: eventsMap.keySet()) {
      scheduleStr.append(dayOfTheWeek.getDayString() + ": " + "\n");
      for (Event eventsInMap: eventsMap.get(dayOfTheWeek)) {

        scheduleStr.append(eventsInMap.eventToString().indent(10) + "\n");
      }
    }
    return scheduleStr.toString();
  }


}
