package view;

public interface ScheduleView {
}
