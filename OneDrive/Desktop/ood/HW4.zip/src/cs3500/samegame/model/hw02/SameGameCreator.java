package cs3500.samegame.model.hw02;

public class SameGameCreator {

  public enum GameType {
    FOURPIECE,
    GRAVITY,
    AUTOMATCH
  }

  public static SameGameModel<Piece> createGame(GameType gametype) {
    switch (gametype) {
      case GameType.AUTOMATCH:
        return new AutoMatchSameGame();
      case GameType.GRAVITY:
        return new GravitySameGame();
      case GameType.FOURPIECE:
        return new FourPieceSameGame();
      default:
        return new FourPieceSameGame();
    }
  }
}
