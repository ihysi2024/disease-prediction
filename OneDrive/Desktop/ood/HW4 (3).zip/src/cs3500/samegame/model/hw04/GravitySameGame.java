package cs3500.samegame.model.hw04;

import java.util.List;

import cs3500.samegame.model.hw02.FourPieceSameGame;
import cs3500.samegame.model.hw02.Piece;
import cs3500.samegame.model.hw02.PieceType;
import cs3500.samegame.model.hw02.SameGameModel;

public class GravitySameGame implements SameGameModel<Piece> {
  protected List<List<Piece>> board;
  protected int rows;
  protected int cols;
  protected int swaps;
  protected int score;
  FourPieceSameGame starterGame;

  public GravitySameGame() {
  }

  public GravitySameGame(FourPieceSameGame starterGame, int rows, int cols, int swaps, int score) {
    this.starterGame = new FourPieceSameGame(board, rows, cols, swaps, score);
  }

  @Override
  public void swap(int fromRow, int fromCol, int toRow, int toCol) {
    this.starterGame.swap(fromRow, fromCol, toRow, toCol);
    //setThisBoard();
    gravity();
  }

  @Override
  public void removeMatch(int row, int col) {
    this.starterGame.removeMatch(row, col);
    //setThisBoard();
    gravity();
  }

  private void gravity() {
    boolean leftAbove = true;

    while (leftAbove) {
      leftAbove = false;
      for (int rowNum = 0; rowNum < this.starterGame.rows - 1; rowNum++) {
        for (int colNum = 0; colNum < this.starterGame.cols - 1; colNum++) {
          if ((this.starterGame.board.get(rowNum).get(colNum).color() != PieceType.EMPTY) &&
          (this.starterGame.board.get(rowNum + 1).get(colNum).color() == PieceType.EMPTY)) {
            leftAbove = true ;
            PieceType color = this.starterGame.board.get(rowNum).get(colNum).color();
            this.starterGame.board.get(rowNum + 1).set(colNum,
                    new Piece(color, (rowNum + 1), colNum));
            this.starterGame.board.get(rowNum).set(colNum,
                    new Piece(PieceType.EMPTY, rowNum, colNum));
          }

        }
      }
    }
  }

  @Override
  public int width() {
    return this.rows;
  }

  @Override
  public int length() {
    return this.starterGame.length();
  }

  @Override
  public Piece pieceAt(int row, int col) {
    return this.starterGame.pieceAt(row, col);
  }

  @Override
  public int score() {
    return this.starterGame.score();
  }

  @Override
  public int remainingSwaps() {
    return this.starterGame.remainingSwaps();
  }

  @Override
  public boolean gameOver() {
    return this.starterGame.gameOver();
  }

  @Override
  public void startGame(int rows, int cols, int swaps, boolean random) {
    this.starterGame.startGame(rows, cols, swaps, random);
    //setThisBoard();
    gravity();
  }

  @Override
  public Piece[] createListOfPieces() {
    return this.starterGame.createListOfPieces();
  }

  @Override
  public void startGame(List<List<Piece>> board, int swaps) {
    this.starterGame.startGame(board, swaps);
    //setThisBoard();
    gravity();
  }
}
