package model;

public interface ReadOnlyPlanner {
}
