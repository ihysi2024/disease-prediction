package view;

import controller.ViewFeatures;
import model.IEvent;
import model.ITime;
import model.IUser;

public interface IScheduleView {

  void display(boolean show);

  void openScheduleView();

  void setCurrentUser();

  IUser getCurrentUser();

  void displayUserSchedule(IUser userToShow);

  void closeScheduleView();

  void addFeatures(ViewFeatures features);

  void addClickListener(ViewFeatures features);

  void addCalendarInfo();

  void saveCalendarInfo();

  IEvent findEventAtTime(ITime timeOfEvent);

}
