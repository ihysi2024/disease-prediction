import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import model.Event;
import model.NUPlanner;
import model.Schedule;
import model.Time;
import model.User;
import view.ScheduleTextView;
import view.ScheduleView;

public class testTextView {
    private Event newMorningLec;
    private Event morningLec;
    private Event morningLecOverlapping;
    private Event morningLecSameTime;
    private Event morningLecEndTime;
    private Event morningSnack;

    private Event afternoonLec;
    private Event officeHours;

    private Event sleep;

    private Event movie;
    private Schedule luciaSchedule;

    private Schedule studentAnonSchedule;

    private Schedule chatSchedule;

    private Schedule emptySchedule;

    private User profLuciaUser;

    private User studentAnonUser;

    private User chatUser;
    private NUPlanner plannerSystem;
    private HashMap<String, String[]> morningLecMap;

    private ScheduleView view;


    @Before
    public void setUp() {

      this.emptySchedule = new Schedule(new ArrayList<>());

      this.profLuciaUser = new User("Prof Lucia", emptySchedule);
      this.studentAnonUser = new User("Student Anon", emptySchedule);
      this.chatUser = new User("Chat", emptySchedule);

      this.morningLec = new Event("CS3500 Morning Lecture",
              new Time( Time.Day.TUESDAY, 9, 50),
              new Time(Time.Day.TUESDAY, 00, 01),
              false,
              "Churchill Hall 101",
              new ArrayList<>(Arrays.asList("Prof. Lucia",
                      "Student Anon",
                      "Chat")));



      this.newMorningLec = new Event("CS3500 Morning Lecture",
              new Time( Time.Day.TUESDAY, 13, 35),
              new Time(Time.Day.TUESDAY, 16, 00),
              false,
              "Churchill Hall 101",
              new ArrayList<>(Arrays.asList("Prof. Lucia",
                      "Student Anon",
                      "Chat")));


      // same time as the morning lecture
      this.morningLecSameTime = new Event("same time morning lecture",
              new Time( Time.Day.TUESDAY, 9, 50),
              new Time(Time.Day.TUESDAY, 11, 30),
              false,
              "Churchill Hall 101",
              new ArrayList<>(Arrays.asList(
                      "Student Anon")));

      // overlapping time as the morning lecture
      this.morningLecOverlapping = new Event("overlapping morning lecture ",
              new Time( Time.Day.TUESDAY, 8, 30),
              new Time(Time.Day.TUESDAY, 10, 30),
              false,
              "Churchill Hall 101",
              new ArrayList<>(Arrays.asList("Prof. Lucia",
                      "Student Anon",
                      "Chat")));

      // start time same as end time of morning lecture
      this.morningLecEndTime = new Event("same start time as end time",
              new Time( Time.Day.TUESDAY, 11, 30),
              new Time(Time.Day.TUESDAY, 12, 15),
              false,
              "Churchill Hall 101",
              new ArrayList<>(Arrays.asList("Prof. Lucia",
                      "Student Anon",
                      "Chat")));

      // same time as the morning lecture
      this.morningLecSameTime = new Event("same time morning lecture",
              new Time( Time.Day.TUESDAY, 9, 50),
              new Time(Time.Day.TUESDAY, 11, 30),
              false,
              "Churchill Hall 101",
              new ArrayList<>(Arrays.asList("Prof. Lucia",
                      "Student Anon",
                      "Chat")));

      // overlapping time as the morning lecture
      this.morningLecOverlapping = new Event("overlapping morning lecture ",
              new Time( Time.Day.TUESDAY, 8, 30),
              new Time(Time.Day.TUESDAY, 10, 30),
              false,
              "Churchill Hall 101",
              new ArrayList<>(Arrays.asList("Prof. Lucia",
                      "Student Anon",
                      "Chat")));

      // start time same as end time of morning lecture
      this.morningLecEndTime = new Event("same start time as end time",
              new Time( Time.Day.TUESDAY, 11, 30),
              new Time(Time.Day.TUESDAY, 12, 15),
              false,
              "Churchill Hall 101",
              new ArrayList<>(Arrays.asList("Prof. Lucia",
                      "Student Anon",
                      "Chat")));

      this.afternoonLec = new Event("CS3500 Afternoon Lecture",
              new Time(Time.Day.TUESDAY, 13, 35),
              new Time(Time.Day.TUESDAY, 15, 15),
              false,
              "Churchill Hall 101",
              new ArrayList<>(Arrays.asList("Prof. Lucia",
                      "Chat")));

      this.sleep = new Event("Sleep",
              new Time(Time.Day.FRIDAY, 18, 0),
              new Time(Time.Day.SUNDAY, 12, 0),
              true,
              "Home",
              new ArrayList<>(Arrays.asList("Prof. Lucia")));

      this.luciaSchedule = new Schedule(new ArrayList<>(Arrays.asList(morningLec, afternoonLec, sleep)));
      this.studentAnonSchedule = new Schedule(new ArrayList<>(Arrays.asList(morningLec)));
      this.chatSchedule = new Schedule(new ArrayList<>(Arrays.asList(morningLec, afternoonLec)));

      this.profLuciaUser = new User("Prof. Lucia", luciaSchedule);
      this.studentAnonUser = new User("Student Anon", studentAnonSchedule);
      this.chatUser = new User("Chat", chatSchedule);

      this.morningSnack = new Event("snack",
              new Time(Time.Day.TUESDAY, 8, 30),
              new Time(Time.Day.TUESDAY, 8, 45),
              false,
              "Churchill Hall 101",
              List.of("Student Anon"));

      this.officeHours = new Event("office hours",
              new Time(Time.Day.THURSDAY, 15, 15),
              new Time(Time.Day.THURSDAY, 16, 30),
              false,
              "Churchill Hall 101",
              List.of("Student Anon",
                      "Prof. Lucia"));

      this.movie = new Event("movie",
              new Time(Time.Day.FRIDAY, 21, 15),
              new Time(Time.Day.FRIDAY, 23, 30),
              true,
              "home",
              List.of("Student Anon"));

      HashSet<User> users = new HashSet<User>();
      users.add(this.profLuciaUser);
      users.add(this.studentAnonUser);
      users.add(this.chatUser);
      this.plannerSystem = new NUPlanner(users);
      this.view = new ScheduleTextView(this.plannerSystem, new StringBuilder());
    }

  /**
   * Tests if the view can correctly convert the planner system to a text view
   * @throws IOException if the schedule cannot be converted correctly
   */

  @Test
  public void testPlannerSystemToString() throws IOException {
      emptySchedule.addEvent(this.morningLec);
      emptySchedule.addEvent(this.afternoonLec);
      emptySchedule.addEvent(this.sleep);
      String planner = "User: Prof. Lucia\n" +
              "Sunday: \n" +
              "Monday: \n" +
              "Tuesday: \n" +
              "name: CS3500 Morning Lecture\n" +
              "time: Tuesday: 09:50->Tuesday: 00:01\n" +
              "location: Churchill Hall 101\n" +
              "online: false\n" +
              "users: Prof. Lucia\n" +
              "Student Anon\n" +
              "Chat          \n" +
              "name: CS3500 Afternoon Lecture\n" +
              "time: Tuesday: 13:35->Tuesday: 15:15\n" +
              "location: Churchill Hall 101\n" +
              "online: false\n" +
              "users: Prof. Lucia\n" +
              "Chat          \n" +
              "Wednesday: \n" +
              "Thursday: \n" +
              "Friday: \n" +
              "name: Sleep\n" +
              "time: Friday: 18:00->Sunday: 12:00\n" +
              "location: Home\n" +
              "online: true\n" +
              "users: Prof. Lucia          \n" +
              "Saturday: \n" +
              "\n" +
              "User: Student Anon\n" +
              "Sunday: \n" +
              "Monday: \n" +
              "Tuesday: \n" +
              "name: CS3500 Morning Lecture\n" +
              "time: Tuesday: 09:50->Tuesday: 00:01\n" +
              "location: Churchill Hall 101\n" +
              "online: false\n" +
              "users: Prof. Lucia\n" +
              "Student Anon\n" +
              "Chat          \n" +
              "Wednesday: \n" +
              "Thursday: \n" +
              "Friday: \n" +
              "Saturday: \n" +
              "\n" +
              "User: Chat\n" +
              "Sunday: \n" +
              "Monday: \n" +
              "Tuesday: \n" +
              "name: CS3500 Morning Lecture\n" +
              "time: Tuesday: 09:50->Tuesday: 00:01\n" +
              "location: Churchill Hall 101\n" +
              "online: false\n" +
              "users: Prof. Lucia\n" +
              "Student Anon\n" +
              "Chat          \n" +
              "name: CS3500 Afternoon Lecture\n" +
              "time: Tuesday: 13:35->Tuesday: 15:15\n" +
              "location: Churchill Hall 101\n" +
              "online: false\n" +
              "users: Prof. Lucia\n" +
              "Chat          \n" +
              "Wednesday: \n" +
              "Thursday: \n" +
              "Friday: \n" +
              "Saturday: \n\n";

      Assert.assertEquals(planner, this.view.plannerSystemString());
  }

  /**
   * Test that the view can correctly output the model's text
   * @throws IOException if the output cannot be rendered
   */

  @Test
  public void testRender() throws IOException {
    Appendable ap = new StringBuilder();
    ScheduleView view = new ScheduleTextView(this.plannerSystem, ap);
    view.renderPlanner();
    StringBuilder rendered = new StringBuilder("User: Prof. Lucia\n" +
            "Sunday: \n" +
            "Monday: \n" +
            "Tuesday: \n" +
            "name: CS3500 Morning Lecture\n" +
            "time: Tuesday: 09:50->Tuesday: 00:01\n" +
            "location: Churchill Hall 101\n" +
            "online: false\n" +
            "users: Prof. Lucia\n" +
            "Student Anon\n" +
            "Chat          \n" +
            "name: CS3500 Afternoon Lecture\n" +
            "time: Tuesday: 13:35->Tuesday: 15:15\n" +
            "location: Churchill Hall 101\n" +
            "online: false\n" +
            "users: Prof. Lucia\n" +
            "Chat          \n" +
            "Wednesday: \n" +
            "Thursday: \n" +
            "Friday: \n" +
            "name: Sleep\n" +
            "time: Friday: 18:00->Sunday: 12:00\n" +
            "location: Home\n" +
            "online: true\n" +
            "users: Prof. Lucia          \n" +
            "Saturday: \n" +
            "\n" +
            "User: Student Anon\n" +
            "Sunday: \n" +
            "Monday: \n" +
            "Tuesday: \n" +
            "name: CS3500 Morning Lecture\n" +
            "time: Tuesday: 09:50->Tuesday: 00:01\n" +
            "location: Churchill Hall 101\n" +
            "online: false\n" +
            "users: Prof. Lucia\n" +
            "Student Anon\n" +
            "Chat          \n" +
            "Wednesday: \n" +
            "Thursday: \n" +
            "Friday: \n" +
            "Saturday: \n" +
            "\n" +
            "User: Chat\n" +
            "Sunday: \n" +
            "Monday: \n" +
            "Tuesday: \n" +
            "name: CS3500 Morning Lecture\n" +
            "time: Tuesday: 09:50->Tuesday: 00:01\n" +
            "location: Churchill Hall 101\n" +
            "online: false\n" +
            "users: Prof. Lucia\n" +
            "Student Anon\n" +
            "Chat          \n" +
            "name: CS3500 Afternoon Lecture\n" +
            "time: Tuesday: 13:35->Tuesday: 15:15\n" +
            "location: Churchill Hall 101\n" +
            "online: false\n" +
            "users: Prof. Lucia\n" +
            "Chat          \n" +
            "Wednesday: \n" +
            "Thursday: \n" +
            "Friday: \n" +
            "Saturday: \n\n");

    Assert.assertEquals(rendered.toString(), ap.toString());
    }

}
