package cs3500.samegame.model.hw04;

import cs3500.samegame.model.hw02.FourPieceSameGame;
import cs3500.samegame.model.hw02.Piece;
import cs3500.samegame.model.hw02.SameGameModel;


public class SameGameCreator {

  public enum GameType {
    FOURPIECE,
    GRAVITY,
    AUTOMATCH
  }

  public static SameGameModel<Piece> createGame(GameType gametype) {
    switch (gametype) {
      case AUTOMATCH:
        return new AutoMatchSameGame();
      case GRAVITY:
        return new GravitySameGame();
      case FOURPIECE:
        return new FourPieceSameGame();
      default:
        return new FourPieceSameGame();
    }
  }
}
