package cs3500.tictactoe.model;

/**
 * Game status
 */
public enum Status {
  Playing, Won, Tied
}
