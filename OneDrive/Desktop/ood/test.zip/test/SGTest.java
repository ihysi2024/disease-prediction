import org.junit.Assert;
import org.junit.Test;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import cs3500.samegame.model.hw02.FourPieceSameGame;
import cs3500.samegame.model.hw02.Piece;
import cs3500.samegame.model.hw02.PieceType;
import cs3500.samegame.view.SameGameTextView;

public class SGTest {

  @Test
  public void removeMatch() {
    List<List<Piece>> pieces = new ArrayList<>();
    FourPieceSameGame fpsg1 = new FourPieceSameGame(pieces, 3, 4, 0, 2);
    List<Piece> row1 = new ArrayList();
    row1.add(new Piece(PieceType.BLUE, 0, 0));
    row1.add(new Piece(PieceType.BLUE, 0, 1));
    row1.add(new Piece(PieceType.BLUE, 0, 2));
    row1.add(new Piece(PieceType.BLUE, 0, 3));
    List<Piece> row2 = new ArrayList();
    row2.add(new Piece(PieceType.RED, 1, 0));
    row2.add(new Piece(PieceType.EMPTY, 1, 1));
    row2.add(new Piece(PieceType.YELLOW, 1, 2));
    row2.add(new Piece(PieceType.GREEN, 1, 3));
    List<Piece> row3 = new ArrayList();
    row3.add(new Piece(PieceType.GREEN, 2, 0));
    row3.add(new Piece(PieceType.BLUE, 2, 1));
    row3.add(new Piece(PieceType.BLUE, 2, 2));
    row3.add(new Piece(PieceType.BLUE, 2, 3));
    pieces.add(row1);
    pieces.add(row2);
    pieces.add(row3);
    fpsg1.startGame(pieces, 0);
    SameGameTextView sg1 = new SameGameTextView(fpsg1);
    System.out.println(sg1.toString());
    Assert.assertFalse(fpsg1.gameOver());
    fpsg1.removeMatch(0,0);
    System.out.println(sg1.toString());
    Assert.assertFalse(fpsg1.gameOver());
  }
}
