package cs3500.samegame.controller;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import cs3500.samegame.model.hw02.SameGameModel;

public class SameGameTextController<T> implements SameGameController<T>{
  private Readable readable;
  private Appendable appendable;
  public SameGameTextController(Readable rd, Appendable ap) {
    if ((rd == null) || (ap == null)) {
      throw new IllegalArgumentException("Input and Output are empty");
    }
    this.readable = rd;
    this.appendable = ap;

  }
  public void playGame(SameGameModel<T> model, int rows, int cols, int swaps, boolean isRandom)
          throws IllegalStateException {
  }

  public void playGame(SameGameModel<T> model, List<List<T>> board, int swaps) throws IllegalStateException {
  }

  /**
   *
  @Override
  public void playGame(SameGameModel<T> model, int rows, int cols, int swaps, boolean isRandom)
          throws IllegalStateException {

    int fromRow;
    int toRow;
    int fromCol;
    int toCol;
    boolean quit = false;
    if (model == null) {
      throw new IllegalArgumentException("Model cannot be null");
    }
    try {
      model.startGame(rows, cols, swaps, isRandom);
    }
    catch (Exception startE) {
      writeMessage("Error: " + startE.getMessage() + System.lineSeparator());
    }
    Scanner sc = new Scanner(this.readable);

    while (!quit || model.gameOver()) {
      String userMove = sc.next();
      switch (userMove) {
        case "quit":
        case "q":

          quit = true;
          break;
        case "m":
          try {
            fromRow = sc.nextInt() - 1;
            fromCol = sc.nextInt() - 1;
            model.removeMatch(fromRow, fromCol);
          } catch (Exception matchE) {
            writeMessage("Error: " + matchE.getMessage() + System.lineSeparator());
          }
          break;
        case "s":
          try {
            fromRow = sc.nextInt() - 1;
            fromCol = sc.nextInt() - 1;
            toRow = sc.nextInt() - 1;
            toCol = sc.nextInt() - 1;
            model.swap(fromRow, fromCol, toRow, toCol);
          } catch (Exception swapE) {
            writeMessage("Error: " + swapE.getMessage() + System.lineSeparator());
          }
          break;
        default:
          writeMessage("Invalid move. Try Again. )
      }
    }

  }

  @Override
  public void playGame(SameGameModel<T> model, List<List<T>> board, int swaps) throws IllegalStateException {
    Scanner sc = new Scanner(this.readable);
    boolean quit = false;
    try {
      model.startGame(board, swaps);
    }
    catch (Exception e) {
      throw new IllegalStateException("Game cannot be started");
    }


  }

  **/
  protected void writeMessage(String message) throws IllegalStateException {
    try {
      appendable.append(message);

    } catch (IOException e) {
      throw new IllegalStateException(e.getMessage());
    }
  }
}